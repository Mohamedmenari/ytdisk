/* Start a multi-frame encode, cancel it, and confirm the UI returns to idle
   without leaving a result or a stuck progress panel. */
(async () => {
  const $ = (s) => document.querySelector(s);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const wait = (cond, ms) => new Promise((res, rej) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      let v = false;
      try { v = cond(); } catch (e) { /* keep waiting */ }
      if (v) { clearInterval(iv); res(v); }
      else if (Date.now() - t0 > ms) { clearInterval(iv); rej(new Error('TIMEOUT')); }
    }, 100);
  });

  const bytes = new Uint8Array(500 * 1024);
  for (let i = 0; i < bytes.length; i++) bytes[i] = (i * 91 + 7) & 0xff;

  $('#tabPack').click();
  document.querySelector('#optHeight button[data-v="1080"]').click();
  document.querySelector('#optBlock button[data-v="4"]').click();
  document.querySelector('#optNsym button[data-v="32"]').click();
  const pw = $('#pw');
  pw.value = '';
  pw.dispatchEvent(new Event('input', { bubbles: true }));
  $('#packClear').click();

  const dt = new DataTransfer();
  dt.items.add(new File([bytes], 'cancel-probe.bin', { type: 'application/octet-stream' }));
  $('#filePack').files = dt.files;
  $('#filePack').dispatchEvent(new Event('change', { bubbles: true }));
  await sleep(120);

  $('#goPack').click();
  await wait(() => !$('#progPack').hidden, 15000);
  await sleep(350);
  $('#cancelPack').click();
  await wait(() => !$('#goPack').disabled, 45000);

  return {
    progressHidden: $('#progPack').hidden,
    resultHidden: $('#outPack').hidden,
    messageHidden: $('#packMsg').hidden,
    message: $('#packMsg').hidden ? '(hidden)' : $('#packMsg').textContent,
    screenTag: $('#screenTag').textContent,
    goEnabled: !$('#goPack').disabled,
  };
})()
