/* Full UI round trip through the real controls: pick a file, render,
   self-check, then feed the produced MP4 into the Unpack panel. */
(async () => {
  const $ = (s) => document.querySelector(s);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const wait = (cond, ms = 90000) => new Promise((res, rej) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      let v = false;
      try { v = cond(); } catch (e) { /* keep waiting */ }
      if (v) { clearInterval(iv); res(v); }
      else if (Date.now() - t0 > ms) { clearInterval(iv); rej(new Error('TIMEOUT ' + cond)); }
    }, 120);
  });

  function setInput(input, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function pickSegment(segId, value) {
    const b = document.querySelector('#' + segId + ' button[data-v="' + value + '"]');
    b.click();
  }

  const results = {};

  async function roundTrip(label, bytes, password) {
    const out = { label };
    // Reset to Pack.
    $('#tabPack').click();
    if (!window.__fourK) pickSegment('optHeight', 1080);
    pickSegment('optBlock', 4);
    pickSegment('optNsym', 32);
    const pw = $('#pw');
    pw.value = password || '';
    pw.dispatchEvent(new Event('input', { bubbles: true }));
    $('#packClear').click();

    const fps = 30;
    setInput($('#filePack'), new File([bytes], 'probe-' + label + '.bin', { type: 'application/octet-stream' }));
    await sleep(150);
    out.ledger = [$('#ledTime').textContent, $('#ledSize').textContent, $('#ledFrames').textContent];
    out.goEnabled = !$('#goPack').disabled;
    if (!$('#goPack').disabled) $('#goPack').click();
    else throw new Error('pack button stayed disabled');

    await wait(() => !$('#outPack').hidden || !$('#packMsg').hidden, 90000);
    if (!$('#packMsg').hidden) {
      out.packError = $('#packMsg').textContent;
      return out;
    }
    out.videoName = $('#outTitle').textContent;
    out.videoSub = $('#outSub').textContent;
    out.blobHref = $('#dlPack').href.slice(0, 5);
    const videoBuf = await (await fetch($('#dlPack').href)).arrayBuffer();
    out.videoBytes = videoBuf.byteLength;
    out.videoMagic = new TextDecoder().decode(new Uint8Array(videoBuf.slice(4, 8)));

    // Self-check button decodes the produced video in place.
    $('#verifyPack').click();
    await wait(() => !$('#verifyMsg').hidden && /Self-check|self-check|passed|failed/.test($('#verifyMsg').textContent), 90000)
      .catch(() => {});
    out.selfCheck = $('#verifyMsg').textContent.trim();

    // Now the Unpack panel.
    $('#tabUnpack').click();
    setInput($('#fileUnpack'), new File([videoBuf], 'probe-' + label + '.ytdisk.mp4', { type: 'video/mp4' }));
    await sleep(150);
    out.unpackGoEnabled = !$('#goUnpack').disabled;
    $('#goUnpack').click();
    await wait(() => !$('#outUnpack').hidden || !$('#unpackMsg').hidden, 90000);
    out.firstPass = $('#unpackMsg').hidden ? 'decoded' : $('#unpackMsg').textContent;
    if (!$('#unpackMsg').hidden && password) {
      // Encrypted videos ask for the password first; enter it and retry.
      out.pwPrompted = !$('#unpackPw').hidden;
      await wait(() => !$('#goUnpack').disabled, 15000);
      // First try a wrong password and confirm the error is specific.
      $('#pw2').value = 'definitely-wrong';
      $('#goUnpack').click();
      await wait(() => /not correct/i.test($('#unpackMsg').textContent), 60000).catch(() => {});
      out.wrongPassword = $('#unpackMsg').textContent;
      await wait(() => !$('#goUnpack').disabled, 15000);
      $('#pw2').value = password;
      $('#goUnpack').click();
      await wait(() => !$('#outUnpack').hidden || !$('#unpackMsg').hidden, 90000);
    }
    if (!$('#unpackMsg').hidden) {
      out.unpackError = $('#unpackMsg').textContent;
      return out;
    }
    out.meta = {
      name: $('#metaName').textContent,
      size: $('#metaSize').textContent,
      frames: $('#metaFrames').textContent,
      block: $('#metaBlock').textContent,
      ecc: $('#metaEcc').textContent,
      hash: $('#metaHash').textContent,
    };
    out.outName = $('#outName').textContent;
    out.outSub = $('#outSub2').textContent;
    const back = new Uint8Array(await (await fetch($('#dlUnpack').href)).arrayBuffer());
    out.backBytes = back.byteLength;
    out.identical = back.byteLength === bytes.length && back.every((v, i) => v === bytes[i]);
    out.preview = $('#outUnpack').hidden ? 'hidden' : 'shown';
    return out;
  }

  // Deterministic payload. Default is one data frame; __large crosses
  // into multi-frame territory so the progress and count paths run.
  const size = window.__large ? 200 * 1024 : 2048;
  const base = new Uint8Array(size);
  for (let i = 0; i < base.length; i++) base[i] = (i * 37 + 11) & 0xff;

  if (window.__fourK) {
    return { fourK: await roundTrip('4k', base, '') };
  }
  if (window.__large) {
    return { large: await roundTrip('large', base, '') };
  }
  if (window.__onlyEnc) {
    return { encrypted: await roundTrip('enc', base, 'correct horse battery') };
  }
  results.plain = await roundTrip('plain', base, '');
  results.encrypted = await roundTrip('enc', base, 'correct horse battery');

  // Error path: drop a non-video into Unpack.
  $('#tabUnpack').click();
  setInput($('#fileUnpack'), new File([new Uint8Array(64)], 'not-a-video.mp4', { type: 'video/mp4' }));
  await sleep(120);
  $('#goUnpack').click();
  await wait(() => !$('#unpackMsg').hidden || !$('#outUnpack').hidden, 30000).catch(() => {});
  results.badVideo = {
    msg: $('#unpackMsg').hidden ? '(none)' : $('#unpackMsg').textContent,
    outHidden: $('#outUnpack').hidden,
  };

  return results;
})()
