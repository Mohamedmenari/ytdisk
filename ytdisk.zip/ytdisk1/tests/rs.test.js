const RS = require('../js/rs.js');
const fs = require('fs');
const path = require('path').join(__dirname, 'rsvec.json');
const vec = JSON.parse(fs.readFileSync(path, 'utf8'));
let fail = 0;

function interleave(seq) {
  const nb = seq.length / 255;
  const out = new Uint8Array(seq.length);
  for (let j = 0; j < 255; j++) for (let b = 0; b < nb; b++) out[j * nb + b] = seq[b * 255 + j];
  return out;
}

for (const v of vec) {
  const msg = Uint8Array.from(Buffer.from(v.msg, 'hex'));
  const seq = Buffer.from(RS.encodeBlock(msg, v.nsym)).toString('hex');
  if (seq !== v.enc) { fail++; console.log('SEQ ENC MISMATCH nsym', v.nsym, 'n', v.n); }
  const want = Buffer.from(interleave(Uint8Array.from(Buffer.from(v.enc, 'hex')))).toString('hex');
  const got = Buffer.from(RS.encodeInterleaved(msg, v.nsym)).toString('hex');
  if (got !== want) { fail++; console.log('INTER ENC MISMATCH nsym', v.nsym, 'n', v.n); }
}

for (const v of vec) {
  const msg = Uint8Array.from(Buffer.from(v.msg, 'hex'));
  const data = new Uint8Array(RS.encodeInterleaved(msg, v.nsym));
  const nCodewords = Math.ceil(msg.length / (255 - v.nsym));
  const maxErr = Math.floor(v.nsym / 2);
  for (let trial = 0; trial < 12; trial++) {
    const bad = data.slice();
    const used = new Set();
    for (let e = 0; e < maxErr; e++) {
      const b = Math.floor(Math.random() * nCodewords);
      const j = Math.floor(Math.random() * 255);
      const idx = j * nCodewords + b;
      if (used.has(idx)) { e--; continue; }
      used.add(idx);
      bad[idx] ^= 1 + Math.floor(Math.random() * 255);
    }
    try {
      const r = RS.decodeInterleaved(bad, nCodewords, v.nsym);
      const got = Buffer.from(r.data.subarray(0, msg.length)).toString('hex');
      if (got !== v.msg) { fail++; console.log('DEC MISMATCH nsym', v.nsym, 'n', v.n); }
    } catch (e) { fail++; console.log('DEC THREW nsym', v.nsym, 'n', v.n, e.message); }
  }
}

let detected = 0;
for (let t = 0; t < 30; t++) {
  const v = vec[0];
  const msg = Uint8Array.from(Buffer.from(v.msg, 'hex'));
  const data = new Uint8Array(RS.encodeInterleaved(msg, v.nsym));
  const nc = Math.ceil(msg.length / (255 - v.nsym));
  for (let e = 0; e < 40; e++) data[Math.floor(Math.random() * 255) * nc] ^= 1 + Math.floor(Math.random() * 255);
  try { RS.decodeInterleaved(data, nc, v.nsym); } catch (e) { detected++; }
}
console.log('over-capacity detected', detected + '/30');
console.log(fail ? 'FAIL ' + fail : 'ALL RS TESTS PASS');
