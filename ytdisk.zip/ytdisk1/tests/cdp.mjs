/* Tiny CDP driver: load a page, wait for a condition, optionally screenshot.
   node tests/cdp.mjs --url file://... --wait-title PASS --timeout 120000
   node tests/cdp.mjs --url http://... --shot out.png --w 1440 --h 900 --full --wait-ms 1500 */
import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { writeFileSync, mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const args = process.argv.slice(2);
const get = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const has = (k) => args.includes('--' + k);

const url = get('url');
const port = 9300 + Math.floor(Math.random() * 300);
const profile = mkdtempSync(join(tmpdir(), 'cdp-'));
const chrome = spawn('chromium-browser', [
  '--headless=old', '--no-sandbox', '--disable-dev-shm-usage',
  '--autoplay-policy=no-user-gesture-required',
  '--remote-debugging-port=' + port,
  '--user-data-dir=' + profile,
  'about:blank',
], { stdio: ['ignore', 'ignore', 'ignore'] });

const timeoutMs = Number(get('timeout', 120000));
const started = Date.now();

async function waitFor(fn, ms, label) {
  while (Date.now() - started < ms) {
    try { const v = await fn(); if (v) return v; } catch (e) { /* retry */ }
    await sleep(200);
  }
  throw new Error('timeout waiting for ' + label);
}

let ws;
try {
  const version = await waitFor(async () => {
    const r = await fetch(`http://127.0.0.1:${port}/json/version`);
    return r.ok ? r.json() : null;
  }, 15000, 'devtools');
  const target = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' }).then(r => r.json());
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0;
  const waiting = new Map();
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && waiting.has(msg.id)) {
      const { res, rej } = waiting.get(msg.id);
      waiting.delete(msg.id);
      msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
    }
  };
  const send = (method, params = {}) => new Promise((res, rej) => {
    const mid = ++id;
    waiting.set(mid, { res, rej });
    ws.send(JSON.stringify({ id: mid, method, params }));
  });

  await send('Page.enable');
  await send('Runtime.enable');

  const vw = Number(get('w', 0));
  const vh = Number(get('h', 0));
  if (vw || vh) {
    await send('Emulation.setDeviceMetricsOverride', {
      width: vw || 1440, height: vh || 900, deviceScaleFactor: 1, mobile: (vw || 1440) < 600,
    });
  }

  await send('Page.navigate', { url });
  if (has('debug')) {
    await sleep(1500);
    const d = await send('Runtime.evaluate', { expression: 'location.href + " | " + document.title + " | " + document.readyState', returnByValue: true });
    console.error('DEBUG', JSON.stringify(d.result && d.result.value));
  }

  if (get('wait-title')) {
    const want = get('wait-title');
    await waitFor(async () => {
      const r = await send('Runtime.evaluate', { expression: 'document.title', returnByValue: true });
      return r.result && r.result.value === want;
    }, timeoutMs, 'title=' + want);
  }
  if (get('file')) {
    await send('DOM.enable');
    const doc = await send('DOM.getDocument', { depth: -1 });
    const q = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: 'input[type=file]' });
    if (!q.nodeId) throw new Error('no file input');
    await send('DOM.setFileInputFiles', { files: [get('file')], nodeId: q.nodeId });
  }
  if (get('wait-ms')) await sleep(Number(get('wait-ms')));
  if (has('wait-fn')) {
    const expr = get('wait-fn');
    await waitFor(async () => {
      const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
      return r.result && r.result.value;
    }, timeoutMs, expr);
  }

  if (get('pre')) {
    await send('Runtime.evaluate', { expression: get('pre'), returnByValue: true, awaitPromise: true });
    await sleep(600);
  }

  const out = await send('Runtime.evaluate', {
    expression: 'document.body ? document.body.innerText : ""',
    returnByValue: true,
  });
  if (has('print')) console.log(out.result.value);

  if (get('shot')) {
    await sleep(400);
    let params = { format: 'png' };
    if (has('full')) {
      const m = await send('Page.getLayoutMetrics');
      const size = m.cssContentSize || m.contentSize;
      params = {
        format: 'png',
        captureBeyondViewport: true,
        clip: { x: 0, y: 0, width: size.width, height: Math.ceil(size.height), scale: 1 },
      };
    }
    const shot = await send('Page.captureScreenshot', params);
    writeFileSync(get('shot'), Buffer.from(shot.data, 'base64'));
    console.log('shot saved', get('shot'), has('full') ? '(full)' : '');
  }
  if (has('eval') || get('eval-file')) {
    const expr = get('eval-file') ? readFileSync(get('eval-file'), 'utf8') : get('eval');
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    const v = r.result && r.result.value;
    console.log(JSON.stringify(v !== undefined ? v : r));
  }
} catch (e) {
  console.error('ERR', e.message);
  process.exitCode = 1;
} finally {
  try { ws && ws.close(); } catch (e) { /* noop */ }
  chrome.kill('SIGKILL');
}
