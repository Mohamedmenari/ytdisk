/* Bilingual copy for the whole page. English is the fallback; Arabic is
   written for the same instrument-register as the original project. */
(function (root) {
  'use strict';

  const EN = {
    skip: 'Skip to the tool',
    brandsub: 'file transport',

    capChecking: 'checking encoder…',
    specSpeed: 'KB/s',
    specTime: 'min per GB',
    specHash: 'checked',
    langLabel: 'Language',
    modeLabel: 'Mode',
    monitorLabel: 'Transmission monitor',
    capReady: 'H.264 4K encoder ready',
    capPartly: 'limited encoder, 1080p only',
    capMissing: 'encoder unavailable',

    h1: 'A file, written into video.',
    lede: 'YTDISK paints any file into a 4K black-and-white test pattern, one frame at a time. Upload the video, download it, and the bytes come back exactly as they went in. The encoder runs in this tab. Nothing is uploaded.',
    warn: 'An educational project, not a storage service. YouTube may re-compress or remove videos, and using it as a disk can break its terms. Keep uploads unlisted, and keep a real copy.',

    monitor: 'TRANSMISSION',
    demo: 'DEMO LOOP',
    rendering: 'RENDERING',
    decoding: 'DECODING',
    complete: 'COMPLETE',
    noSignal: 'NO SIGNAL',

    rGrid: 'GRID',
    rCell: 'CELL',
    rBits: 'BITS / FRAME',
    rPay: 'DATA / FRAME',

    tabPack: 'Pack',
    tabUnpack: 'Unpack',

    dropFile: 'Drop a file here',
    orBrowse: 'or choose one from this device',
    dropAny: 'Any type. Keep it under 300 MB.',
    remove: 'Remove',

    cell: 'Cell size',
    cell4: 'denser',
    cell8: 'sturdier',
    ecc: 'Error correction',
    ecc32: 'standard',
    ecc64: 'double',
    off: 'off',
    ecc0: 'raw',
    output: 'Output',
    out4k: 'YouTube',
    out1080: 'local',
    password: 'Password',
    optional: 'optional',
    show: 'show',
    hide: 'hide',

    ledTime: 'Video length',
    ledSize: 'Approx. video size',
    ledFrames: 'Data frames',

    render: 'Render the video',
    cancel: 'Cancel',
    downloadVideo: 'Download video',
    selfCheck: 'Self-check',

    step1: 'Upload it to YouTube Studio as <b>Unlisted</b>.',
    step2: 'Wait until <b>2160p</b> appears in the quality menu.',
    step3: 'Download the MP4: <code>yt-dlp -f "bv*[ext=mp4][height&gt;=2160]"</code>',
    step4: 'Come back to <b>Unpack</b> with the downloaded file.',
    fine: 'Rendered locally with WebCodecs. No upload, no account.',

    dropVideo: 'Drop the downloaded video',
    dropVideoB: 'or choose an MP4 from this device',
    dropVideoC: 'Grab the 2160p MP4 from YouTube, not the 1080p one.',

    mFile: 'FILE',
    mSize: 'SIZE',
    mFrames: 'FRAMES',
    mBlock: 'CELL',
    mEcc: 'ECC',
    mHash: 'SHA-256',

    passwordNeeded: 'Password',
    extract: 'Extract the file',
    downloadFile: 'Download file',
    fine2: 'Decoded locally. The video is never uploaded.',

    howh: 'What happens to your file',
    howp: 'The same path the original Python tool takes, rebuilt for the browser.',
    s1h: 'Fingerprint',
    s1p: 'SHA-256 of your file is written into the header, so the decoder can prove nothing changed.',
    s2h: 'Protect',
    s2p: 'Reed–Solomon adds 32 parity bytes per 255-byte codeword, then interleaves them so a damaged patch of video doesn\u2019t kill one codeword.',
    s3h: 'Paint',
    s3p: 'Each bit is a cell: white for 1, black for 0. 129,600 cells per frame, 30 frames a second, upscaled to 4K.',
    s4h: 'Prove',
    s4p: 'On the way back, parity repairs bit errors, the hash is recomputed, and you get a verdict: byte-identical, or not.',

    proofh: 'Measured, not promised',
    proofp: 'From the project\u2019s own tests, on simulated YouTube compression. 4×4 cells at 4K survived with zero lost bytes. That\u2019s the default here.',
    proofmini: '1 GB works out to roughly 42 minutes of video. It is a real cost, not a footnote.',

    tRes: 'Video',
    tCell: 'Cell',
    tType: 'Signal',
    tCap: 'Payload',
    tLost: 'Bytes lost',
    tOut: 'Result',
    bw: 'black &amp; white',
    color: 'colour',
    grey: '4 grey levels',
    works: 'works',
    fails: 'fails',

    limh: 'Before you trust it with anything',
    l1: '<b>There is no promise.</b> A re-encode, a region change, a takedown, and the file is gone. This is a demonstration of error-correcting codes, not a backup.',
    l2: '<b>It is slow and heavy.</b> A gigabyte is ~42 minutes of 4K video. Uploading and downloading takes longer than that.',
    l3: '<b>It may break the rules.</b> YouTube\u2019s terms don\u2019t invite data storage. Use unlisted videos on a test channel, and never as the only copy.',
    l4: '<b>A drive is cheaper.</b> 15 GB on Google Drive, free, no 4K encode, no waiting for 2160p to appear.',

    footBuild: 'Rebuilt for the browser from',
    footVideo: 'the original video',
    footLocal: 'Runs locally · MIT',

    stHash: 'Hashing the file…',
    stEncrypt: 'Encrypting with AES-256…',
    stEcc: 'Adding parity bytes…',
    stRender: 'Painting frames…',
    stDemux: 'Reading the video container…',
    stHeader: 'Looking for the header…',
    stCollect: 'Collecting frames…',
    stRepair: 'Repairing errors…',
    stDecrypt: 'Decrypting…',
    stVerify: 'Verifying the hash…',

    selfRunning: 'Decoding the video back…',
    selfOk: 'Self-check passed. The video decodes to the original file.',
    selfFail: 'Self-check failed. This video does not decode cleanly.',

    errNoEncoder: 'This browser has no H.264 encoder available. Try desktop Chrome or Edge.',
    errCancelled: 'Cancelled.',
    errNoHeader: 'No YTDISK header found. Make sure you downloaded the full 2160p file, not a clip.',
    errTooShort: 'The video is shorter than its header claims: {a} of {b} data frames. Download the whole file.',
    errRs: 'The data could not be repaired. This video is damaged beyond the parity budget.',
    errPwNeeded: 'This video is encrypted. Enter its password to continue.',
    errPwWrong: 'That password is not correct.',
    errNoDecoder: 'This browser cannot decode the H.264 stream in this video.',
    errTooBig: 'This file is too large to process in one tab. Try something smaller.',
    errNotVideo: 'This is not a readable video file, or its MP4 container is damaged.',
    errGeneric: 'Something unexpected happened. Try again, or use a different browser.',

    framesUnit: 'frames',
    frameOne: 'frame',
    dataWord: 'data',
    repaired: '{n} symbols repaired',
    noRepair: '0 symbols repaired',
  };

  const AR = {
    skip: 'تخطَّ إلى الأداة',
    brandsub: 'نقل الملفات',

    capChecking: 'جارٍ فحص المُرمِّز…',
    specSpeed: 'KB/s',
    specTime: 'دقيقة/جيجابايت',
    specHash: 'موثّق',
    langLabel: 'اللغة',
    modeLabel: 'الوضع',
    monitorLabel: 'شاشة البث',
    capReady: 'مُرمِّز H.264 بدقة 4K جاهز',
    capPartly: 'مُرمِّز محدود، 1080p فقط',
    capMissing: 'المُرمِّز غير متاح',

    h1: 'ملف، مكتوب داخل فيديو.',
    lede: 'يرسم YTDISK أي ملف داخل نمط اختبار أبيض وأسود بدقة 4K، إطارًا بإطار. ارفع الفيديو، ثم نزّله، وترجع البايتات كما دخلت تمامًا. الترميز يجري داخل هذا التاب. لا شيء يُرفع إلى أي مكان.',
    warn: 'مشروع تعليمي، وليس خدمة تخزين. قد يعيد يوتيوب ضغط الفيديوهات أو يحذفها، واستخدامه كقرص قد يخالف شروطه. اجعل الرفع غير مُدرج، واحتفظ دائمًا بنسخة حقيقية.',

    monitor: 'بث',
    demo: 'حلقة تجريبية',
    rendering: 'جارٍ الإنشاء',
    decoding: 'جارٍ الفك',
    complete: 'اكتمل',
    noSignal: 'لا إشارة',

    rGrid: 'الشبكة',
    rCell: 'الخلية',
    rBits: 'بت / إطار',
    rPay: 'بيانات / إطار',

    tabPack: 'حزم',
    tabUnpack: 'فك',

    dropFile: 'أفلت ملفًا هنا',
    orBrowse: 'أو اختر واحدًا من هذا الجهاز',
    dropAny: 'أي نوع. أقل من 300 ميجابايت.',
    remove: 'إزالة',

    cell: 'حجم الخلية',
    cell4: 'أكثف',
    cell8: 'أمتن',
    ecc: 'تصحيح الأخطاء',
    ecc32: 'قياسي',
    ecc64: 'مضاعف',
    off: 'إيقاف',
    ecc0: 'خام',
    output: 'الإخراج',
    out4k: 'يوتيوب',
    out1080: 'محلي',
    password: 'كلمة المرور',
    optional: 'اختياري',
    show: 'إظهار',
    hide: 'إخفاء',

    ledTime: 'طول الفيديو',
    ledSize: 'حجم الفيديو تقريبًا',
    ledFrames: 'إطارات البيانات',

    render: 'أنشئ الفيديو',
    cancel: 'إلغاء',
    downloadVideo: 'نزّل الفيديو',
    selfCheck: 'فحص ذاتي',

    step1: 'ارفعه إلى YouTube Studio بوصفه <b>غير مُدرج</b>.',
    step2: 'انتظر حتى تظهر <b>2160p</b> في قائمة الجودة.',
    step3: 'نزّل ملف MP4: <code>yt-dlp -f "bv*[ext=mp4][height&gt;=2160]"</code>',
    step4: 'عُد إلى <b>فك</b> بالملف الذي نزّلته.',
    fine: 'يُعالج محليًا عبر WebCodecs. بلا رفع، بلا حساب.',

    dropVideo: 'أفلت الفيديو الذي نزّلته',
    dropVideoB: 'أو اختر ملف MP4 من هذا الجهاز',
    dropVideoC: 'خذ ملف MP4 بدقة 2160p من يوتيوب، لا نسخة 1080p.',

    mFile: 'الملف',
    mSize: 'الحجم',
    mFrames: 'الإطارات',
    mBlock: 'الخلية',
    mEcc: 'التصحيح',
    mHash: 'SHA-256',

    passwordNeeded: 'كلمة المرور',
    extract: 'استخرج الملف',
    downloadFile: 'نزّل الملف',
    fine2: 'يُفك محليًا. الفيديو لا يُرفع أبدًا.',

    howh: 'ما الذي يحدث لملفك',
    howp: 'نفس المسار الذي تسلكه أداة بايثون الأصلية، معاد بناؤه للمتصفح.',
    s1h: 'البصمة',
    s1p: 'تُكتب بصمة SHA-256 لملفك داخل الترويسة، فيستطيع المفك إثبات أن شيئًا لم يتغير.',
    s2h: 'الحماية',
    s2p: 'يضيف Reed–Solomon 32 بايت تعويض لكل 255 بايت، ثم يوزّعها بالتناوب كي لا يقتل تلف بقعة واحدة كلمة ترميز واحدة.',
    s3h: 'الرسم',
    s3p: 'كل بت خلية: أبيض لـ1، أسود لـ0. 129,600 خلية في الإطار، 30 إطارًا في الثانية، مكبّرة إلى 4K.',
    s4h: 'الإثبات',
    s4p: 'في طريق العودة، تُصلح بايتات التعويض أخطاء البتات، وتُحسب البصمة من جديد، فتحصل على حكم: مطابق بايت ببايت، أو لا.',

    proofh: 'مقيس، لا موعود',
    proofp: 'من اختبارات المشروع نفسه، على ضغط يوتيوب المحاكى. خلايا 4×4 بدقة 4K نجت دون فقد بايت واحد. وهذا هو الافتراضي هنا.',
    proofmini: '1 جيجابايت يساوي نحو 42 دقيقة فيديو. هذه تكلفة حقيقية، ليست هامشًا.',

    tRes: 'الفيديو',
    tCell: 'الخلية',
    tType: 'الإشارة',
    tCap: 'الحمولة',
    tLost: 'بايتات مفقودة',
    tOut: 'النتيجة',
    bw: 'أبيض وأسود',
    color: 'ملون',
    grey: '4 مستويات رمادي',
    works: 'يعمل',
    fails: 'يفشل',

    limh: 'قبل أن تأتمنه على أي شيء',
    l1: '<b>لا يوجد وعد.</b> إعادة ترميز، أو تغيير منطقة، أو حذف، ويضيع الملف. هذا عرض لأكواد تصحيح الأخطاء، وليس نسخًا احتياطيًا.',
    l2: '<b>بطيء وثقيل.</b> الجيجابايت نحو 42 دقيقة فيديو 4K. والرفع والتنزيل يستغرقان وقتًا أطول من ذلك.',
    l3: '<b>قد يخالف القواعد.</b> شروط يوتيوب لا تدعو إلى تخزين البيانات. استخدم فيديوهات غير مُدرجة على قناة تجريبية، ولا تجعله النسخة الوحيدة أبدًا.',
    l4: '<b>القرص أرخص.</b> 15 جيجابايت على Google Drive، مجانًا، بلا ترميز 4K، وبلا انتظار ظهور 2160p.',

    footBuild: 'أُعيد بناؤه للمتصفح من',
    footVideo: 'الفيديو الأصلي',
    footLocal: 'يعمل محليًا · MIT',

    stHash: 'أحسب البصمة…',
    stEncrypt: 'أشفّر بـ AES-256…',
    stEcc: 'أضيف بايتات التعويض…',
    stRender: 'أرسم الإطارات…',
    stDemux: 'أقرأ حاوية الفيديو…',
    stHeader: 'أبحث عن الترويسة…',
    stCollect: 'أجمع الإطارات…',
    stRepair: 'أصلح الأخطاء…',
    stDecrypt: 'أفك التشفير…',
    stVerify: 'أتحقق من البصمة…',

    selfRunning: 'أفك الفيديو من جديد…',
    selfOk: 'نجح الفحص الذاتي. الفيديو يعود إلى الملف الأصلي.',
    selfFail: 'فشل الفحص الذاتي. هذا الفيديو لا يُفك بنظافة.',

    errNoEncoder: 'هذا المتصفح لا يوفّر مُرمِّز H.264. جرّب Chrome أو Edge على سطح المكتب.',
    errCancelled: 'أُلغي.',
    errNoHeader: 'لم أجد ترويسة YTDISK. تأكد أنك نزّلت ملف 2160p كاملًا، لا مقطعًا منه.',
    errTooShort: 'الفيديو أقصر مما تقوله ترويسته: {a} من {b} إطار بيانات. نزّل الملف كاملًا.',
    errRs: 'تعذّر إصلاح البيانات. الفيديو تلف أكثر من ميزانية التعويض.',
    errPwNeeded: 'هذا الفيديو مشفّر. أدخل كلمة المرور للمتابعة.',
    errPwWrong: 'كلمة المرور غير صحيحة.',
    errNoDecoder: 'هذا المتصفح لا يستطيع فك ترميز H.264 في هذا الفيديو.',
    errTooBig: 'هذا الملف أكبر من أن يُعالج في تاب واحد. جرّب ملفًا أصغر.',
    errNotVideo: 'هذا ليس ملف فيديو مقروءًا، أو أن حاوية MP4 تالفة.',
    errGeneric: 'حدث خطأ غير متوقع. أعد المحاولة، أو جرّب متصفحًا آخر.',

    framesUnit: 'إطارات',
    frameOne: 'إطار',
    dataWord: 'بيانات',
    repaired: 'أُصلح {n} رمزًا',
    noRepair: 'لم يُصلح أي رمز',
  };

  const DICT = { en: EN, ar: AR };
  let lang = 'en';

  function t(key, vars) {
    const table = DICT[lang] || EN;
    let s = table[key];
    if (s == null) s = EN[key];
    if (s == null) s = key;
    if (vars) {
      for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
    }
    return s;
  }

  function apply(scope) {
    const rootEl = scope || document;
    rootEl.querySelectorAll('[data-i18n]').forEach((el) => {
      el.innerHTML = t(el.getAttribute('data-i18n'));
    });
    rootEl.querySelectorAll('[data-i18n-aria]').forEach((el) => {
      el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria')));
    });
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.title = lang === 'ar' ? 'YTDISK · ملف داخل فيديو' : 'YTDISK · a file inside a video';
    const desc = document.getElementById('metaDesc');
    if (desc) {
      desc.setAttribute('content', lang === 'ar'
        ? 'حوِّل أي ملف إلى نمط اختبار بدقة 4K، وارفعه كفيديو، ثم فكّه ليعود بايتًا ببايت. يعمل بالكامل داخل متصفحك.'
        : 'Turn any file into a 4K test pattern, upload it as a video, and decode it back byte for byte. Runs entirely in your browser.');
    }
    document.querySelectorAll('[data-lang]').forEach((b) => {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-lang') === lang));
    });
  }

  function set(next) {
    lang = next === 'ar' ? 'ar' : 'en';
    try { localStorage.setItem('ytdisk.lang', lang); } catch (e) { /* private mode */ }
    apply();
    document.dispatchEvent(new CustomEvent('ytdisk:lang', { detail: { lang } }));
  }

  function init() {
    let saved = null;
    try { saved = localStorage.getItem('ytdisk.lang'); } catch (e) { /* ignore */ }
    const auto = (navigator.language || '').toLowerCase().indexOf('ar') === 0 ? 'ar' : 'en';
    lang = saved === 'ar' || saved === 'en' ? saved : auto;
    apply();
  }

  root.I18n = { t, apply, set, init, get lang() { return lang; } };
})(typeof globalThis !== 'undefined' ? globalThis : this);
