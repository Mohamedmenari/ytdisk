/* Encode/decode pipelines on top of WebCodecs + the YTDISK format core. */
(function (root) {
  'use strict';

  const FMT = Engine.FMT;
  const tick = () => new Promise(r => setTimeout(r, 0));

  const CODECS = {
    2160: 'avc1.640033',
    1080: 'avc1.64002a',
  };

  function bitrateFor(height) {
    return height >= 2160 ? 30000000 : 10000000;
  }

  function trimName(name) {
    let n = name.replace(/[\u0000-\u001f]/g, '').slice(0, 120);
    return n || 'file.bin';
  }

  async function pickCodec(width, height, bitrate) {
    const tries = [
      { codec: CODECS[height] || CODECS[2160], width, height, bitrate, framerate: FMT.FPS, latencyMode: 'quality', avc: { format: 'avc' } },
      { codec: 'avc1.42E033', width, height, bitrate, framerate: FMT.FPS, latencyMode: 'quality', avc: { format: 'avc' } },
    ];
    if (height <= 1080) {
      tries.push({ codec: 'vp09.00.10.08', width, height, bitrate, framerate: FMT.FPS });
      tries.push({ codec: 'vp8', width, height, bitrate, framerate: FMT.FPS });
    }
    for (const cfg of tries) {
      try {
        const res = await VideoEncoder.isConfigSupported(cfg);
        if (res.supported) return res.config;
      } catch (e) { /* try next */ }
    }
    return null;
  }

  /**
   * Encode bytes into an MP4 blob.
   * opts: { bytes, name, block, nsym, password, height, onProgress, onFrame, shouldCancel }
   */
  async function encode(opts) {
    const { bytes, name, block, nsym, password, height: heightPx } = opts;
    const onProgress = opts.onProgress || (() => {});
    const onFrame = opts.onFrame || (() => {});
    const shouldCancel = opts.shouldCancel || (() => false);

    onProgress({ phase: 'hash', pct: 0 });
    const sha = await Engine.sha256Hex(bytes);
    if (shouldCancel()) throw new Error('CANCELLED');

    let payload = bytes;
    if (password) {
      onProgress({ phase: 'encrypt', pct: 0.01 });
      payload = await Scrypt.encrypt(bytes, password);
    }
    if (shouldCancel()) throw new Error('CANCELLED');

    onProgress({ phase: 'ecc', pct: 0.02 });
    const ecc = RS.encodeInterleaved(payload, nsym);
    const bpf = Engine.bitsPerFrame(block);
    const nFrames = Math.ceil((ecc.length * 8) / bpf);
    const codewords = nsym === 0 ? 0 : Math.ceil(payload.length / (FMT.RS_N - nsym));

    const safeName = trimName(name);
    const meta = {
      magic: FMT.MAGIC, v: FMT.VERSION, name: safeName, size: bytes.length,
      sha256: sha, payload_len: payload.length, codewords,
      block, nsym, frames: nFrames, encrypted: !!password,
    };
    const headerBytes = Engine.buildHeaderBytes(meta);

    const width = Math.round((heightPx * 16) / 9), planW = width;
    const bitrate = bitrateFor(heightPx);
    const cfg = await pickCodec(planW, heightPx, bitrate);
    if (!cfg) throw new Error('NO_ENCODER');

    const writer = new Mp4.Mp4Writer({ width: planW, height: heightPx, fps: FMT.FPS });
    let decoderConfig = null;
    let encoderError = null;

    const encoder = new VideoEncoder({
      output: (chunk, meta2) => {
        if (meta2 && meta2.decoderConfig && meta2.decoderConfig.description) {
          decoderConfig = new Uint8Array(meta2.decoderConfig.description);
        }
        writer.addChunk(chunk);
      },
      error: (e) => { encoderError = e; },
    });
    encoder.configure(cfg);

    const renderer = new Engine.FrameRenderer();
    const big = document.createElement('canvas');
    big.width = width;
    big.height = heightPx;
    const bigCtx = big.getContext('2d');
    bigCtx.imageSmoothingEnabled = false;

    const totalFrames = FMT.HEADER_FRAMES + nFrames;
    let encoded = 0;
    const frameDur = 1e6 / FMT.FPS;

    async function push(bits, bitOffset, blockSize, isHeader) {
      const small = renderer.draw(bits, bitOffset, blockSize);
      bigCtx.drawImage(small, 0, 0, width, heightPx);

      onFrame(small, encoded, totalFrames);
      const frame = new VideoFrame(big, {
        timestamp: Math.round(encoded * frameDur),
        duration: Math.round(frameDur),
      });
      encoder.encode(frame, { keyFrame: encoded % FMT.FPS === 0 });
      frame.close();
      encoded++;
      if (encoderError) throw encoderError;
      while (encoder.encodeQueueSize > 2) await tick();
      if (encoded % 2 === 0) {
        onProgress({ phase: 'render', pct: encoded / totalFrames, frame: encoded, total: totalFrames, key: writer.count });
        await tick();
        if (shouldCancel()) throw new Error('CANCELLED');
      }
    }

    try {
      for (let i = 0; i < FMT.HEADER_FRAMES; i++) {
        await push(headerBytes, 0, FMT.HEADER_BLOCK, true);
      }
      for (let i = 0; i < nFrames; i++) {
        await push(ecc, i * bpf, block, false);
      }
      await encoder.flush();
      if (encoderError) throw encoderError;
      if (!decoderConfig) throw new Error('NO_CODEC_DESCRIPTION');
      writer.description = decoderConfig;
      const blob = writer.finalize();
      onProgress({ phase: 'done', pct: 1, filesize: blob.size });
      return { blob, meta, sha, duration: totalFrames / FMT.FPS, filesize: blob.size, bitrate };
    } finally {
      try { encoder.close(); } catch (e) { /* already closed */ }
    }
  }

  async function waitForSupport(codec, width, height) {
    try {
      const res = await VideoDecoder.isConfigSupported({ codec, codedWidth: width, codedHeight: height });
      return !!res.supported;
    } catch (e) {
      return false;
    }
  }

  /**
   * Decode a YTDISK video. Returns { meta, bytes, sha, shaOk, fixed }.
   * opts: { password, onProgress, onHeader, shouldCancel }
   */
  async function decode(file, opts) {
    opts = opts || {};
    const onProgress = opts.onProgress || (() => {});
    const onHeader = opts.onHeader || (() => {});
    const shouldCancel = opts.shouldCancel || (() => false);
    const password = opts.password || null;

    onProgress({ phase: 'demux', pct: 0 });
    const demux = await Mp4.demuxMp4(file);
    if (!demux.samples.length) throw new Error('NO_SAMPLES');
    if (!await waitForSupport(demux.codec, demux.codedWidth || 1920, demux.codedHeight || 1080)) {
      throw new Error('NO_DECODER');
    }

    const reader = new Engine.FrameReader();
    const pending = [];
    let decoderError = null;
    let meta = null;
    let headerSeen = 0;
    let dataStarted = false;
    let dataFrames = 0;
    let collected = null;
    let bytesPerFrame = 0;
    let ended = false;
    let index = 0;

    const decoder = new VideoDecoder({
      output: (frame) => pending.push(frame),
      error: (e) => { decoderError = e; },
    });
    decoder.configure({
      codec: demux.codec,
      description: demux.description || undefined,
      codedWidth: demux.codedWidth || undefined,
      codedHeight: demux.codedHeight || undefined,
      optimizeForLatency: true,
    });

    function setMeta(m) {
      if (!m.block || m.block < 2 || m.block > 64) throw new Error('BAD_HEADER');
      const bpf = Engine.bitsPerFrame(m.block);
      if (bpf % 8 !== 0) throw new Error('BAD_HEADER');
      bytesPerFrame = bpf / 8;
      const need = bytesPerFrame * m.frames;
      if (need > 512 * 1024 * 1024) throw new Error('TOO_BIG');
      collected = new Uint8Array(need);
      meta = m;
      onHeader(m);
    }

    function handleFrame(frame) {
      try {
        const img = reader.grab(frame);
        if (!meta) {
          const m = Engine.parseHeaderBytes(reader.bitsFrom(img, FMT.HEADER_BLOCK));
          if (m) { setMeta(m); headerSeen++; return; }
          if (index > 89) ended = true;
          return;
        }
        if (headerSeen < FMT.HEADER_FRAMES + 2) {
          const hm = Engine.parseHeaderBytes(reader.bitsFrom(img, FMT.HEADER_BLOCK));
          if (hm) { headerSeen++; return; }
        }
        if (!dataStarted) dataStarted = true;
        if (dataFrames < meta.frames) {
          const frameBytes = reader.bitsFrom(img, meta.block);
          collected.set(frameBytes.subarray(0, bytesPerFrame), dataFrames * bytesPerFrame);
          dataFrames++;
          onProgress({ phase: 'collect', pct: dataFrames / meta.frames, frame: dataFrames, total: meta.frames });
          if (dataFrames >= meta.frames) ended = true;
        }
      } finally {
        frame.close();
      }
    }

    let sampleIdx = 0;
    while (!ended && !decoderError) {
      if (pending.length) {
        handleFrame(pending.shift());
        index++;
        if (ended) break;
        if (shouldCancel()) throw new Error('CANCELLED');
        continue;
      }
      if (sampleIdx >= demux.samples.length) break;
      const s = demux.samples[sampleIdx++];
      try {
        decoder.decode(new EncodedVideoChunk({
          type: s.key ? 'key' : 'delta',
          timestamp: Math.round((s.dts * 1e6) / demux.timescale),
          duration: Math.round((s.duration * 1e6) / demux.timescale),
          data: demux.buf.subarray(s.offset, s.offset + s.size),
        }));
      } catch (e) {
        throw new Error('DECODE_FAILED');
      }
      await tick();
    }

    if (!ended && !decoderError) {
      try { await decoder.flush(); } catch (e) { /* noop */ }
      while (pending.length && !ended) {
        handleFrame(pending.shift());
        index++;
        if (shouldCancel()) throw new Error('CANCELLED');
      }
    }
    try { decoder.close(); } catch (e) { /* noop */ }
    if (!meta) throw new Error('NO_HEADER');
    if (dataFrames < meta.frames) throw new Error('TOO_SHORT:' + dataFrames + ':' + meta.frames);

    onProgress({ phase: 'ecc', pct: 0 });
    await tick();
    let payload, fixed = 0;
    try {
      const res = RS.decodeInterleaved(collected, meta.codewords, meta.nsym);
      payload = res.data.subarray(0, meta.payload_len);
      fixed = res.fixed;
    } catch (e) {
      throw new Error('RS_FAILED');
    }

    if (meta.encrypted) {
      if (!password) throw new Error('PASSWORD_REQUIRED');
      onProgress({ phase: 'decrypt', pct: 0 });
      try {
        payload = await Scrypt.decrypt(payload, password);
      } catch (e) {
        throw new Error('WRONG_PASSWORD');
      }
    }

    const sha = await Engine.sha256Hex(payload);
    const shaOk = sha === meta.sha256;
    return { meta, bytes: payload, sha, shaOk, fixed, headerSeen, dataFrames };
  }

  root.Pipeline = { encode, decode, waitForSupport, pickCodec };
})(typeof globalThis !== 'undefined' ? globalThis : this);
