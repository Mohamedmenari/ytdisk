/* Minimal ISO-BMFF (MP4) writer for a single H.264 video track, plus a demuxer
   for progressive MP4 files. No dependencies, no server. */
(function (root) {
  'use strict';

  const enc = new TextEncoder();

  function u8(...vals) { return Uint8Array.from(vals.flat()); }
  function u16(n) { return new Uint8Array([(n >>> 8) & 255, n & 255]); }
  function u32(n) { return new Uint8Array([(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255]); }
  function str4(s) { return enc.encode(s).slice(0, 4); }

  function concat(parts) {
    let len = 0;
    for (const p of parts) len += p.byteLength;
    const out = new Uint8Array(len);
    let off = 0;
    for (const p of parts) { out.set(p, off); off += p.byteLength; }
    return out;
  }

  function box(type, ...parts) {
    const body = concat(parts);
    return concat([u32(body.byteLength + 8), str4(type), body]);
  }

  function fullBox(type, version, flags, ...parts) {
    return box(type, u8(version, (flags >>> 16) & 255, (flags >>> 8) & 255, flags & 255), ...parts);
  }

  const MATRIX = concat([u32(0x00010000), u32(0), u32(0), u32(0), u32(0x00010000), u32(0), u32(0), u32(0), u32(0x40000000)]);

  function avc1(width, height, avcC) {
    const name = new Uint8Array(32);
    const label = enc.encode('YTDISK Video Handler').slice(0, 31);
    name[0] = label.length;
    name.set(label, 1);
    return box('avc1',
      new Uint8Array(6), u16(1),
      u16(0), u16(0), new Uint8Array(12),
      u16(width), u16(height),
      u32(0x00480000), u32(0x00480000),
      u32(0), u16(1),
      name,
      u16(0x0018), u16(0xffff),
      box('avcC', avcC),
      box('pasp', u32(1), u32(1))
    );
  }

  class Mp4Writer {
    constructor(opts) {
      this.width = opts.width;
      this.height = opts.height;
      this.fps = opts.fps || 30;
      this.description = opts.description;
      this.samples = [];
      this.bytes = 0;
    }

    addChunk(chunk) {
      const data = new Uint8Array(chunk.byteLength);
      chunk.copyTo(data);
      this.samples.push({ data, key: chunk.type === 'key' });
      this.bytes += data.byteLength;
    }

    get count() { return this.samples.length; }
    get duration() { return this.samples.length / this.fps; }

    finalize() {
      const n = this.samples.length;
      const fps = this.fps;
      const movieTimescale = 1000;
      const movieDuration = Math.round(n * movieTimescale / fps);
      const trackDuration = n;

      const ftyp = box('ftyp', str4('isom'), u32(512), str4('isom'), str4('iso2'), str4('avc1'), str4('mp41'));
      const mdatHeader = u32(this.bytes + 8) && concat([u32(this.bytes + 8), str4('mdat')]);
      const mdatStart = ftyp.byteLength + mdatHeader.byteLength;

      const offsets = [];
      const sizes = [];
      let cursor = mdatStart;
      for (const s of this.samples) {
        offsets.push(cursor);
        sizes.push(s.data.byteLength);
        cursor += s.data.byteLength;
      }

      const stts = fullBox('stts', 0, 0, u32(1), u32(n), u32(1));
      const stss = fullBox('stss', 0, 0,
        u32(this.samples.filter(s => s.key).length),
        ...this.samples.map((s, i) => s.key ? u32(i + 1) : new Uint8Array(0)));
      const stsc = fullBox('stsc', 0, 0, u32(1), u32(1), u32(1), u32(1));
      const stsz = fullBox('stsz', 0, 0, u32(0), u32(n), ...sizes.map(u32));
      const stco = fullBox('stco', 0, 0, u32(n), ...offsets.map(u32));
      const stsd = fullBox('stsd', 0, 0, u32(1), avc1(this.width, this.height, this.description));

      const stbl = box('stbl', stsd, stts, stss, stsc, stsz, stco);
      const vmhd = fullBox('vmhd', 0, 1, u16(0), u16(0), u16(0), u16(0));
      const dref = fullBox('dref', 0, 0, u32(1), fullBox('url ', 0, 1));
      const dinf = box('dinf', dref);
      const minf = box('minf', vmhd, dinf, stbl);
      const hdlr = fullBox('hdlr', 0, 0, u32(0), str4('vide'), new Uint8Array(12), enc.encode('VideoHandler\u0000'));
      const mdhd = fullBox('mdhd', 0, 0, u32(0), u32(0), u32(fps), u32(trackDuration), u16(0x55c4), u16(0));
      const mdia = box('mdia', mdhd, hdlr, minf);
      const tkhd = fullBox('tkhd', 0, 3, u32(0), u32(0), u32(1), u32(0), u32(movieDuration),
        new Uint8Array(8), u16(0), u16(0), u16(0), u16(0), MATRIX,
        u32(this.width * 65536), u32(this.height * 65536));
      const trak = box('trak', tkhd, mdia);
      const mvhd = fullBox('mvhd', 0, 0, u32(0), u32(0), u32(movieTimescale), u32(movieDuration),
        u32(0x00010000), u16(0x0100), u16(0), new Uint8Array(8), MATRIX, new Uint8Array(24), u32(2));
      const moov = box('moov', mvhd, trak);

      const parts = [ftyp, mdatHeader, ...this.samples.map(s => s.data), moov];
      return new Blob(parts, { type: 'video/mp4' });
    }
  }

  // ---------- demuxer ----------

  function readBoxes(buf, start, end) {
    const out = [];
    let off = start;
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    while (off + 8 <= end) {
      let size = dv.getUint32(off);
      const type = String.fromCharCode(buf[off + 4], buf[off + 5], buf[off + 6], buf[off + 7]);
      let header = 8;
      if (size === 1) {
        const hi = dv.getUint32(off + 8), lo = dv.getUint32(off + 12);
        size = hi * 4294967296 + lo;
        header = 16;
      } else if (size === 0) {
        size = end - off;
      }
      if (size < header || off + size > end) break;
      out.push({ type, start: off, body: off + header, end: off + size });
      off += size;
    }
    return out;
  }

  function findBox(buf, start, end, path) {
    let list = readBoxes(buf, start, end);
    let found = null;
    for (const name of path) {
      found = list.find(b => b.type === name);
      if (!found) return null;
      list = readBoxes(buf, found.body, found.end);
    }
    return found;
  }

  function findBoxes(buf, start, end, type) {
    return readBoxes(buf, start, end).filter(b => b.type === type);
  }

  function codecFromAvcC(d) {
    const hex = (v) => v.toString(16).padStart(2, '0');
    return 'avc1.' + hex(d[1]) + hex(d[2]) + hex(d[3]);
  }

  function codecFromAv1C(d) {
    // av1C: marker(1)|version(7), seq_profile(3)|seq_level_idx(5), seq_tier(1)|high_bitdepth(1)|twelve_bit(1)|mono(1)|...
    const profile = (d[1] >> 5) & 7;
    const level = d[1] & 31;
    const tier = (d[2] >> 7) & 1;
    const high = (d[2] >> 6) & 1;
    const twelve = (d[2] >> 5) & 1;
    const depth = twelve ? 12 : (high ? 10 : 8);
    return `av01.${profile}.${String(level).padStart(2, '0')}${tier ? 'H' : 'M'}.${String(depth).padStart(2, '0')}`;
  }

  function codecFromVpcC(d) {
    // vpcC: version(1) flags(3) profile(1) level(1) bitDepth(4)|chroma(3)|range(1)
    const profile = d[4], level = d[5], depth = d[6] >> 4;
    return `vp09.${String(profile).padStart(2, '0')}.${String(level).padStart(2, '0')}.${String(depth).padStart(2, '0')}`;
  }

  function readSampleTable(buf, trak) {
    const stbl = findBox(buf, trak.body, trak.end, ['mdia', 'minf', 'stbl']);
    if (!stbl) return null;
    const children = readBoxes(buf, stbl.body, stbl.end);
    const get = (t) => children.find(b => b.type === t);
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);

    const stsd = get('stsd');
    if (!stsd) return null;
    const entries = readBoxes(buf, stsd.body + 8, stsd.end);
    const entry = entries[0];
    if (!entry) return null;

    let codec = null, description = null;
    const codedWidth = dv.getUint16(entry.body + 24);
    const codedHeight = dv.getUint16(entry.body + 26);
    const children2 = readBoxes(buf, entry.body + 78, entry.end);
    const findChild = (t) => children2.find(b => b.type === t);
    const avcC = findChild('avcC'), av1C = findChild('av1C'), vpcC = findChild('vpcC');
    if (avcC) {
      description = buf.slice(avcC.body, avcC.end);
      codec = codecFromAvcC(description);
    } else if (av1C) {
      description = buf.slice(av1C.body, av1C.end);
      codec = codecFromAv1C(description);
    } else if (vpcC) {
      description = buf.slice(vpcC.body, vpcC.end);
      codec = codecFromVpcC(description);
    } else {
      return null;
    }

    const mdhd = findBox(buf, trak.body, trak.end, ['mdia', 'mdhd']);
    let timescale = 1000;
    if (mdhd) {
      const ver = buf[mdhd.body];
      timescale = ver === 1
        ? dv.getUint32(mdhd.body + 20)
        : dv.getUint32(mdhd.body + 12);
    }

    const stsz = get('stsz');
    const stts = get('stts');
    const stsc = get('stsc');
    const stco = get('stco') || get('co64');
    const stss = get('stss');
    if (!stsz || !stts || !stsc || !stco) return null;

    const sampleCount = dv.getUint32(stsz.body + 8);
    const fixedSize = dv.getUint32(stsz.body + 4);
    const sizes = new Array(sampleCount);
    for (let i = 0; i < sampleCount; i++) {
      sizes[i] = fixedSize || dv.getUint32(stsz.body + 12 + i * 4);
    }

    const stscCount = dv.getUint32(stsc.body + 4);
    const stscEntries = [];
    for (let i = 0; i < stscCount; i++) {
      const o = stsc.body + 8 + i * 12;
      stscEntries.push({ first: dv.getUint32(o), perChunk: dv.getUint32(o + 4) });
    }

    const chunkCount = dv.getUint32(stco.body + 4);
    const is64 = stco.type === 'co64';
    const chunkOffsets = new Array(chunkCount);
    for (let i = 0; i < chunkCount; i++) {
      if (is64) {
        const o = stco.body + 8 + i * 8;
        chunkOffsets[i] = dv.getUint32(o) * 4294967296 + dv.getUint32(o + 4);
      } else {
        chunkOffsets[i] = dv.getUint32(stco.body + 8 + i * 4);
      }
    }

    const sttsCount = dv.getUint32(stts.body + 4);
    const timeEntries = [];
    for (let i = 0; i < sttsCount; i++) {
      const o = stts.body + 8 + i * 8;
      timeEntries.push({ count: dv.getUint32(o), delta: dv.getUint32(o + 4) });
    }

    let keySet = null;
    if (stss) {
      const count = dv.getUint32(stss.body + 4);
      keySet = new Set();
      for (let i = 0; i < count; i++) keySet.add(dv.getUint32(stss.body + 8 + i * 4) - 1);
    }

    // Build a flat sample list using the chunk map.
    const samples = [];
    let sampleIndex = 0;
    let timeIndex = 0;
    let timeLeft = timeEntries.length ? timeEntries[0].count : 0;
    let dts = 0;
    let stscIdx = 0;
    for (let c = 0; c < chunkCount && sampleIndex < sampleCount; c++) {
      while (stscIdx + 1 < stscEntries.length && stscEntries[stscIdx + 1].first <= c + 1) stscIdx++;
      const perChunk = stscEntries[stscIdx].perChunk;
      let offset = chunkOffsets[c];
      for (let k = 0; k < perChunk && sampleIndex < sampleCount; k++) {
        while (timeLeft === 0 && timeIndex + 1 < timeEntries.length) {
          timeIndex++;
          timeLeft = timeEntries[timeIndex].count;
        }
        const delta = timeEntries.length ? timeEntries[timeIndex].delta : 1;
        samples.push({
          offset,
          size: sizes[sampleIndex],
          dts,
          duration: delta,
          key: keySet ? keySet.has(sampleIndex) : true,
        });
        offset += sizes[sampleIndex];
        dts += delta;
        sampleIndex++;
        timeLeft--;
      }
    }

    return { codec, description, codedWidth, codedHeight, timescale, samples };
  }

  async function demuxMp4(blob) {
    const buf = new Uint8Array(await blob.arrayBuffer());
    const top = readBoxes(buf, 0, buf.byteLength);
    const moov = top.find(b => b.type === 'moov');
    if (!moov) throw new Error('NO_MOOV');
    const traks = findBoxes(buf, moov.body, moov.end, 'trak');
    for (const trak of traks) {
      const hdlr = findBox(buf, trak.body, trak.end, ['mdia', 'hdlr']);
      if (!hdlr) continue;
      const handler = String.fromCharCode(buf[hdlr.body + 8], buf[hdlr.body + 9], buf[hdlr.body + 10], buf[hdlr.body + 11]);
      if (handler !== 'vide') continue;
      const table = readSampleTable(buf, trak);
      if (!table) continue;
      return Object.assign({ buf }, table);
    }
    throw new Error('NO_VIDEO_TRACK');
  }

  root.Mp4 = { Mp4Writer, demuxMp4, box };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.Mp4;
})(typeof globalThis !== 'undefined' ? globalThis : this);
