/* UI wiring: file selection, options, capacity ledger, encode/decode runs,
   progress, self-check, language, and the idle monitor loop. */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const t = (k, v) => I18n.t(k, v);
  const FMT = Engine.FMT;

  const state = {
    pack: null,
    unpack: null,
    block: 4,
    nsym: 32,
    height: 2160,
    password: '',
    busy: null,
    cancel: false,
    lastEncode: null,
    unpackMeta: null,
    caps: { fourK: false, hd: false, webcodecs: false },
    capKey: 'capChecking',
    screenState: 'demo',
    demo: true,
  };

  const el = {};
  const ids = [
    'dropPack', 'filePack', 'packFile', 'packName', 'packSize', 'packClear',
    'optBlock', 'optNsym', 'optHeight', 'pw', 'pwShow',
    'ledTime', 'ledSize', 'ledFrames', 'goPack',
    'progPack', 'progLabel', 'progPct', 'progBar', 'progSub', 'cancelPack', 'packMsg',
    'outPack', 'outTitle', 'outSub', 'dlPack', 'verifyPack', 'verifyMsg', 'stepsNext',
    'tabPack', 'tabUnpack', 'panelPack', 'panelUnpack',
    'dropUnpack', 'fileUnpack', 'unpackFile', 'unpackName', 'unpackSize', 'unpackClear',
    'unpackMeta', 'metaName', 'metaSize', 'metaFrames', 'metaBlock', 'metaEcc', 'metaHash',
    'unpackPw', 'pw2', 'pwShow2', 'goUnpack',
    'progUnpack', 'progLabel2', 'progPct2', 'progBar2', 'progSub2', 'cancelUnpack', 'unpackMsg',
    'outUnpack', 'outName', 'outSub2', 'dlUnpack', 'unpackTick',
    'preview', 'tc', 'roRes', 'roGrid', 'roCell', 'roBits', 'roPay',
    'screenTag', 'screenNote', 'cap', 'capsLine',
  ];
  for (const id of ids) el[id] = $(id);

  /* ── formatting ─────────────────────────────────────────── */

  const nf = new Intl.NumberFormat('en-US');

  function fmtBytes(n) {
    if (!isFinite(n) || n < 0) return '—';
    if (n < 1024) return Math.round(n) + ' B';
    if (n < 1048576) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  }

  function fmtDur(sec) {
    const s = Math.max(0, Math.round(sec));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    const mm = String(m).padStart(2, '0');
    const sss = String(ss).padStart(2, '0');
    return h ? h + ':' + mm + ':' + sss : mm + ':' + sss;
  }

  function pad2(n) { return String(n).padStart(2, '0'); }

  function frameWord(n) {
    return t(Number(n) === 1 ? 'frameOne' : 'framesUnit');
  }

  function setTc(frame) {
    const f = frame % FMT.FPS;
    const total = Math.floor(frame / FMT.FPS);
    const s = total % 60;
    const m = Math.floor(total / 60) % 60;
    const h = Math.floor(total / 3600);
    el.tc.textContent = pad2(h) + ':' + pad2(m) + ':' + pad2(s) + ':' + pad2(f);
  }

  function safeFilename(name) {
    return String(name || 'file.bin').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 160) || 'file.bin';
  }

  function videoName(name) {
    const base = safeFilename(name).replace(/\.[^.]+$/, '');
    return base + '.ytdisk.mp4';
  }

  /* ── error mapping ──────────────────────────────────────── */

  function mapError(err) {
    const raw = String((err && err.message) || err || '');
    if (raw.indexOf('TOO_SHORT:') === 0) {
      const parts = raw.split(':');
      return t('errTooShort', { a: parts[1] || '?', b: parts[2] || '?' });
    }
    switch (raw) {
      case 'NO_ENCODER': return t('errNoEncoder');
      case 'CANCELLED': return t('errCancelled');
      case 'NO_HEADER': return t('errNoHeader');
      case 'RS_FAILED': return t('errRs');
      case 'PASSWORD_REQUIRED': return t('errPwNeeded');
      case 'WRONG_PASSWORD': return t('errPwWrong');
      case 'NO_DECODER': return t('errNoDecoder');
      case 'TOO_BIG': return t('errTooBig');
      case 'NO_MOOV':
      case 'NO_VIDEO_TRACK':
      case 'NO_SAMPLES':
      case 'DECODE_FAILED': return t('errNotVideo');
      default:
        if (!raw || raw === 'undefined') return t('errGeneric');
        if (/memory|allocat|Array buffer/i.test(raw)) return t('errTooBig');
        if (/decoder|codec/i.test(raw)) return t('errNoDecoder');
        return t('errGeneric');
    }
  }

  function showMsg(node, text) {
    node.textContent = text;
    node.hidden = false;
  }

  function hideMsg(node) {
    node.hidden = true;
    node.textContent = '';
  }

  /* ── monitor ────────────────────────────────────────────── */

  const renderer = new Engine.FrameRenderer();
  const demo = { buf: null, bits: 0, offset: 0, frame: 0, last: 0, raf: 0, reduce: false };

  function setScreenTag(key) {
    state.screenState = key;
    el.screenTag.textContent = t(key);
  }

  function buildDemo() {
    const block = 16;
    const bpf = Engine.bitsPerFrame(block);
    demo.bits = bpf * 3;
    demo.buf = new Uint8Array(Math.ceil((demo.bits + bpf) / 8));
    let s = 0x9e3779b9;
    for (let i = 0; i < demo.buf.length; i++) {
      s = (s * 1664525 + 1013904223) >>> 0;
      demo.buf[i] = s >>> 24;
    }
    // A quiet diagonal stripe keeps the wall from reading as pure noise.
    for (let i = 0; i < demo.buf.length; i += 97) demo.buf[i] ^= 0xff;
  }

  const preview = el.preview;
  preview.width = 960;
  preview.height = 540;
  const pctx = preview.getContext('2d');

  function paintPreview(source) {
    pctx.imageSmoothingEnabled = false;
    pctx.drawImage(source, 0, 0, preview.width, preview.height);
  }

  function demoLoop(ts) {
    if (!state.demo) return;
    if (!demo.last || ts - demo.last > 62) {
      demo.last = ts;
      demo.offset = (demo.offset + 113) % demo.bits;
      paintPreview(renderer.draw(demo.buf, demo.offset, 16));
      demo.frame += 2;
      setTc(demo.frame);
    }
    demo.raf = requestAnimationFrame(demoLoop);
  }

  function startDemo() {
    if (demo.reduce || state.busy) return;
    state.demo = true;
    if (!demo.buf) buildDemo();
    if (!demo.raf) demo.raf = requestAnimationFrame(demoLoop);
  }

  function stopDemo() {
    state.demo = false;
    if (demo.raf) cancelAnimationFrame(demo.raf);
    demo.raf = 0;
    demo.last = 0;
  }

  function noSignal() {
    stopDemo();
    pctx.fillStyle = '#0b0b09';
    pctx.fillRect(0, 0, preview.width, preview.height);
    setScreenTag('noSignal');
    el.screenNote.hidden = false;
    el.screenNote.textContent = t('errNoEncoder');
  }

  /* ── readouts ───────────────────────────────────────────── */

  function capacityNow() { return Engine.capacity(state.block, state.nsym); }

  function updateReadout() {
    const c = capacityNow();
    el.roGrid.textContent = c.cols + ' × ' + c.rows;
    el.roCell.textContent = state.block + ' px';
    el.roBits.textContent = nf.format(c.bitsPerFrame);
    el.roPay.textContent = nf.format(Math.floor(c.usefulPerFrame)) + ' B';
    el.roRes.textContent = state.height >= 2160 ? '3840 × 2160' : '1920 × 1080';
  }

  function updateLedger() {
    if (!state.pack) {
      el.ledTime.textContent = '—';
      el.ledSize.textContent = '—';
      el.ledFrames.textContent = '—';
      if (!state.busy) el.goPack.disabled = true;
      return;
    }
    const payload = state.pack.size + (state.password ? 44 : 0);
    const eccLen = state.nsym ? Math.ceil(payload / (FMT.RS_N - state.nsym)) * FMT.RS_N : payload;
    const bpf = Engine.bitsPerFrame(state.block);
    const frames = Math.max(1, Math.ceil((eccLen * 8) / bpf));
    const total = frames + FMT.HEADER_FRAMES;
    const seconds = total / FMT.FPS;
    const bitrate = state.height >= 2160 ? 30000000 : 10000000;
    el.ledTime.textContent = fmtDur(seconds);
    el.ledSize.textContent = fmtBytes((bitrate / 8) * seconds);
    el.ledFrames.textContent = nf.format(frames) + ' (+' + FMT.HEADER_FRAMES + ')';
    if (!state.busy) el.goPack.disabled = state.pack.size > 300 * 1024 * 1024;
  }

  /* ── options ────────────────────────────────────────────── */

  function setSegActive(seg, value) {
    seg.querySelectorAll('button[data-v]').forEach((b) => {
      const on = Number(b.getAttribute('data-v')) === value;
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', String(on));
    });
  }

  function initSegs() {
    document.querySelectorAll('.seg').forEach((seg) => {
      seg.querySelectorAll('button[data-v]').forEach((b) => b.setAttribute('aria-pressed', String(b.classList.contains('on'))));
      seg.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-v]');
        if (!btn || !seg.contains(btn)) return;
        const v = Number(btn.getAttribute('data-v'));
        if (seg === el.optBlock) state.block = v;
        else if (seg === el.optNsym) state.nsym = v;
        else if (seg === el.optHeight) state.height = v;
        setSegActive(seg, v);
        updateReadout();
        updateLedger();
        setScreenTag(state.busy ? state.screenState : 'demo');
      });
    });
    setSegActive(el.optBlock, state.block);
    setSegActive(el.optNsym, state.nsym);
    setSegActive(el.optHeight, state.height);
  }

  /* ── tabs ───────────────────────────────────────────────── */

  function setMode(mode) {
    const pack = mode !== 'unpack';
    el.tabPack.setAttribute('aria-selected', String(pack));
    el.tabUnpack.setAttribute('aria-selected', String(!pack));
    el.panelPack.hidden = !pack;
    el.panelUnpack.hidden = pack;
    if (!pack) hideMsg(el.unpackMsg);
  }

  function initTabs() {
    el.tabPack.addEventListener('click', () => setMode('pack'));
    el.tabUnpack.addEventListener('click', () => setMode('unpack'));
    [el.tabPack, el.tabUnpack].forEach((tab) => {
      tab.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'Home' && e.key !== 'End') return;
        e.preventDefault();
        const next = tab === el.tabPack ? el.tabUnpack : el.tabPack;
        const target = e.key === 'Home' ? el.tabPack : e.key === 'End' ? el.tabUnpack : next;
        target.focus();
        target.click();
      });
    });
  }

  /* ── file inputs ────────────────────────────────────────── */

  function wireDrop(label, input, onFile) {
    ['dragenter', 'dragover'].forEach((ev) => {
      label.addEventListener(ev, (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
        label.classList.add('is-over');
      });
    });
    ['dragleave', 'dragend'].forEach((ev) => {
      label.addEventListener(ev, () => label.classList.remove('is-over'));
    });
    label.addEventListener('drop', (e) => {
      e.preventDefault();
      label.classList.remove('is-over');
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) onFile(file);
    });
    input.addEventListener('change', () => {
      const file = input.files && input.files[0];
      if (file) onFile(file);
      input.value = '';
    });
    label.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        input.click();
      }
    });
  }

  function choosePack(file) {
    state.pack = file;
    el.packFile.hidden = false;
    el.dropPack.hidden = true;
    el.packName.textContent = file.name;
    el.packName.title = file.name;
    el.packSize.textContent = fmtBytes(file.size);
    hideMsg(el.packMsg);
    el.screenNote.hidden = true;
    setScreenTag('demo');
    updateLedger();
    startDemo();
  }

  function clearPack() {
    if (state.busy) return;
    state.pack = null;
    el.packFile.hidden = true;
    el.dropPack.hidden = false;
    el.outPack.hidden = true;
    hideMsg(el.packMsg);
    updateLedger();
  }

  function chooseUnpack(file) {
    state.unpack = file;
    state.unpackMeta = null;
    el.unpackFile.hidden = false;
    el.dropUnpack.hidden = true;
    el.unpackName.textContent = file.name;
    el.unpackName.title = file.name;
    el.unpackSize.textContent = fmtBytes(file.size);
    el.unpackMeta.hidden = true;
    el.unpackPw.hidden = true;
    el.pw2.value = '';
    el.outUnpack.hidden = true;
    hideMsg(el.unpackMsg);
    el.screenNote.hidden = true;
    setScreenTag('demo');
    if (!state.busy) el.goUnpack.disabled = false;
    startDemo();
  }

  function clearUnpack() {
    if (state.busy) return;
    state.unpack = null;
    state.unpackMeta = null;
    el.unpackFile.hidden = true;
    el.dropUnpack.hidden = false;
    el.unpackMeta.hidden = true;
    el.unpackPw.hidden = true;
    el.outUnpack.hidden = true;
    hideMsg(el.unpackMsg);
    el.goUnpack.disabled = true;
  }

  /* ── password reveal ────────────────────────────────────── */

  function wireReveal(input, button) {
    button.addEventListener('click', () => {
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      button.textContent = t(showing ? 'show' : 'hide');
      button.setAttribute('aria-label', t(showing ? 'show' : 'hide'));
      input.focus();
    });
  }

  function syncReveal() {
    [[el.pw, el.pwShow], [el.pw2, el.pwShow2]].forEach(([input, button]) => {
      const showing = input.type === 'text';
      button.textContent = t(showing ? 'hide' : 'show');
      button.setAttribute('aria-label', t(showing ? 'hide' : 'show'));
    });
  }

  /* ── progress ───────────────────────────────────────────── */

  function setProgress(kind, pct, label, sub) {
    const p = kind === 'pack' ? el.progPack : el.progUnpack;
    const pctEl = kind === 'pack' ? el.progPct : el.progPct2;
    const barEl = kind === 'pack' ? el.progBar : el.progBar2;
    const labEl = kind === 'pack' ? el.progLabel : el.progLabel2;
    const subEl = kind === 'pack' ? el.progSub : el.progSub2;
    p.hidden = false;
    const clamped = Math.max(0, Math.min(100, Math.round(pct)));
    pctEl.textContent = clamped + '%';
    barEl.style.width = clamped + '%';
    if (label != null) labEl.textContent = label;
    if (sub != null) subEl.textContent = sub;
  }

  function hideProgress(kind) {
    (kind === 'pack' ? el.progPack : el.progUnpack).hidden = true;
  }

  function setBusy(kind) {
    state.busy = kind;
    const packBusy = kind === 'pack';
    const unpackBusy = kind === 'unpack';
    el.goPack.disabled = !!kind || !state.pack;
    el.goUnpack.disabled = !!kind || !state.unpack;
    el.filePack.disabled = !!kind;
    el.fileUnpack.disabled = !!kind;
    el.panelPack.setAttribute('aria-busy', String(packBusy));
    el.panelUnpack.setAttribute('aria-busy', String(unpackBusy));
  }

  /* ── pack ───────────────────────────────────────────────── */

  async function runPack() {
    if (state.busy || !state.pack) return;
    if (state.pack.size > 300 * 1024 * 1024) {
      showMsg(el.packMsg, t('errTooBig'));
      return;
    }
    hideMsg(el.packMsg);
    el.outPack.hidden = true;
    el.verifyMsg.hidden = true;
    el.verifyMsg.className = 'verify';
    el.screenNote.hidden = true;
    stopDemo();
    state.demo = false;
    setScreenTag('rendering');
    setBusy('pack');
    state.cancel = false;
    setProgress('pack', 0, t('stHash'), '');

    let bytes;
    try {
      bytes = new Uint8Array(await state.pack.arrayBuffer());
    } catch (e) {
      state.busy = null;
      setBusy(null);
      hideProgress('pack');
      showMsg(el.packMsg, t('errTooBig'));
      startDemo();
      return;
    }

    const password = state.password || null;
    const originalName = state.pack.name;
    const originalSize = state.pack.size;

    try {
      const res = await Pipeline.encode({
        bytes,
        name: originalName,
        block: state.block,
        nsym: state.nsym,
        password,
        height: state.height,
        shouldCancel: () => state.cancel,
        onFrame: (small, index) => {
          paintPreview(small);
          setTc(index);
        },
        onProgress: (p) => {
          if (p.phase === 'hash') {
            setProgress('pack', 0, t('stHash'), 'SHA-256 · ' + fmtBytes(originalSize));
          } else if (p.phase === 'encrypt') {
            setProgress('pack', 2, t('stEncrypt'), 'scrypt N=2¹⁵ · r=8 · p=1');
          } else if (p.phase === 'ecc') {
            const c = capacityNow();
            setProgress('pack', 4, t('stEcc'), nf.format(c.cols) + ' × ' + nf.format(c.rows) + ' · ' + state.block + ' px');
          } else if (p.phase === 'render') {
            setProgress('pack', Math.min(99, 4 + p.pct * 96), t('stRender'),
              nf.format(p.frame) + ' / ' + nf.format(p.total) + ' ' + frameWord(p.total));
          } else if (p.phase === 'done') {
            setProgress('pack', 100, t('stRender'), fmtBytes(p.filesize || 0));
          }
        },
      });

      const filename = videoName(originalName);
      if (state.lastEncode && state.lastEncode.url) URL.revokeObjectURL(state.lastEncode.url);
      const url = URL.createObjectURL(res.blob);
      state.lastEncode = {
        blob: res.blob, name: filename, sha: res.sha, size: originalSize,
        password, url,
      };

      el.dlPack.href = url;
      el.dlPack.download = filename;
      el.outTitle.textContent = filename;
      el.outTitle.title = filename;
      el.outSub.textContent = [
        fmtBytes(res.filesize),
        fmtDur(res.duration),
        state.height >= 2160 ? '3840 × 2160' : '1920 × 1080',
        nf.format(res.meta.frames) + ' ' + frameWord(res.meta.frames),
      ].join(' · ');
      el.outPack.hidden = false;
      el.outPack.classList.remove('bad');
      el.verifyMsg.hidden = true;
      el.verifyMsg.className = 'verify';
      el.verifyPack.disabled = false;
      setScreenTag('complete');
      hideProgress('pack');
    } catch (e) {
      hideProgress('pack');
      if (String(e && e.message) === 'CANCELLED') {
        startDemo();
        setScreenTag('demo');
      } else {
        showMsg(el.packMsg, mapError(e));
        setScreenTag('noSignal');
        el.screenNote.hidden = false;
        el.screenNote.textContent = mapError(e);
      }
    } finally {
      setBusy(null);
      updateLedger();
    }
  }

  async function runSelfCheck() {
    const last = state.lastEncode;
    if (!last || el.verifyPack.disabled) return;
    el.verifyMsg.hidden = false;
    el.verifyMsg.className = 'verify';
    el.verifyMsg.textContent = t('selfRunning');
    el.verifyPack.disabled = true;
    try {
      const r = await Pipeline.decode(last.blob, { password: last.password });
      const ok = r.shaOk && r.bytes.length === last.size;
      el.verifyMsg.className = 'verify' + (ok ? '' : ' bad');
      el.verifyMsg.textContent = ok ? t('selfOk') : t('selfFail');
      el.outPack.classList.toggle('bad', !ok);
    } catch (e) {
      el.verifyMsg.className = 'verify bad';
      el.verifyMsg.textContent = mapError(e);
      el.outPack.classList.add('bad');
    } finally {
      el.verifyPack.disabled = false;
    }
  }

  /* ── unpack ─────────────────────────────────────────────── */

  function fillMeta(m) {
    state.unpackMeta = m;
    el.metaName.textContent = m.name;
    el.metaName.title = m.name;
    el.metaSize.textContent = fmtBytes(m.size);
    el.metaFrames.textContent = nf.format(m.frames) + ' (+' + FMT.HEADER_FRAMES + ')';
    el.metaBlock.textContent = m.block + ' px';
    el.metaEcc.textContent = m.nsym === 0 ? t('off') : String(m.nsym);
    el.metaHash.textContent = String(m.sha256 || '').slice(0, 16) + '…';
    el.metaHash.title = m.sha256 || '';
    el.unpackMeta.hidden = false;
    if (m.encrypted) el.unpackPw.hidden = false;
  }

  async function runUnpack() {
    if (state.busy || !state.unpack) return;
    hideMsg(el.unpackMsg);
    el.outUnpack.hidden = true;
    el.outUnpack.classList.remove('bad');
    el.screenNote.hidden = true;
    stopDemo();
    state.demo = false;
    setScreenTag('decoding');
    setBusy('unpack');
    state.cancel = false;
    setProgress('unpack', 1, t('stHeader'), '');

    const password = el.pw2.value || null;

    try {
      const r = await Pipeline.decode(state.unpack, {
        password,
        shouldCancel: () => state.cancel,
        onHeader: (m) => {
          fillMeta(m);
          setProgress('unpack', 4, t('stCollect'), '');
        },
        onProgress: (p) => {
          if (p.phase === 'demux') {
            setProgress('unpack', 2, t('stDemux'), fmtBytes(state.unpack.size));
          } else if (p.phase === 'collect') {
            setProgress('unpack', 4 + p.pct * 72, t('stCollect'),
              nf.format(p.frame) + ' / ' + nf.format(p.total) + ' ' + frameWord(p.total));
          } else if (p.phase === 'ecc') {
            setProgress('unpack', 80, t('stRepair'), p.fixed != null ? t('repaired', { n: p.fixed }) : '');
          } else if (p.phase === 'decrypt') {
            setProgress('unpack', 88, t('stDecrypt'), 'AES-256-GCM · scrypt');
          }
        },
      });

      const blob = new Blob([r.bytes], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const name = safeFilename(r.meta.name);
      el.dlUnpack.href = url;
      el.dlUnpack.download = name;
      el.outName.textContent = name;
      el.outName.title = name;
      el.unpackTick.textContent = r.shaOk ? '✓' : '!';
      el.outUnpack.classList.toggle('bad', !r.shaOk);
      el.outSub2.textContent = [
        fmtBytes(r.bytes.length),
        r.shaOk ? 'SHA-256 ✓' : 'SHA-256 ✗',
        r.fixed ? t('repaired', { n: nf.format(r.fixed) }) : t('noRepair'),
      ].join(' · ');
      el.outUnpack.hidden = false;
      setProgress('unpack', 100, t('stVerify'), '');
      hideProgress('unpack');
      setScreenTag('complete');
      el.screenNote.hidden = true;
    } catch (e) {
      hideProgress('unpack');
      const raw = String(e && e.message || '');
      if (raw === 'CANCELLED') {
        startDemo();
        setScreenTag('demo');
      } else if (raw === 'PASSWORD_REQUIRED') {
        el.unpackPw.hidden = false;
        showMsg(el.unpackMsg, t('errPwNeeded'));
        setTimeout(() => el.pw2.focus(), 30);
        startDemo();
        setScreenTag('demo');
      } else {
        showMsg(el.unpackMsg, mapError(e));
        setScreenTag('noSignal');
        el.screenNote.hidden = false;
        el.screenNote.textContent = mapError(e);
      }
    } finally {
      setBusy(null);
      if (state.unpack) el.goUnpack.disabled = false;
    }
  }

  /* ── capability ─────────────────────────────────────────── */

  async function avcSupport(width, height, bitrate) {
    if (typeof VideoEncoder === 'undefined') return null;
    const codecs = height >= 2160 ? ['avc1.640033', 'avc1.640034'] : ['avc1.64002a', 'avc1.42E02a', 'avc1.42E033'];
    for (const codec of codecs) {
      try {
        const res = await VideoEncoder.isConfigSupported({
          codec, width, height, bitrate, framerate: FMT.FPS,
          latencyMode: 'quality', avc: { format: 'avc' },
        });
        if (res.supported) return res.config;
      } catch (e) { /* next */ }
    }
    return null;
  }

  async function checkCaps() {
    const hasCodecs = typeof VideoEncoder !== 'undefined' && typeof VideoDecoder !== 'undefined';
    state.caps.webcodecs = hasCodecs && window.isSecureContext;
    if (!state.caps.webcodecs) {
      state.capKey = 'capMissing';
      el.cap.querySelector('span').textContent = t('capMissing');
      el.cap.querySelector('.led').className = 'led off';
      el.capsLine.textContent = 'WebCodecs · unavailable';
      noSignal();
      el.goPack.disabled = true;
      return;
    }
    el.cap.querySelector('.led').className = 'led ok';
    const fourK = await avcSupport(3840, 2160, 30000000);
    state.caps.fourK = !!fourK;
    state.caps.hd = !!fourK || !!(await avcSupport(1920, 1080, 10000000));

    if (!state.caps.hd) {
      state.capKey = 'capMissing';
      el.cap.querySelector('span').textContent = t('capMissing');
      el.cap.querySelector('.led').className = 'led off';
      el.capsLine.textContent = 'WebCodecs · H.264 unavailable';
      noSignal();
      el.goPack.disabled = true;
      return;
    }
    if (!state.caps.fourK) {
      state.height = 1080;
      setSegActive(el.optHeight, 1080);
      el.optHeight.querySelectorAll('button[data-v]').forEach((b) => {
        if (Number(b.getAttribute('data-v')) === 2160) { b.disabled = true; b.style.opacity = '0.4'; b.title = t('capPartly'); }
      });
      state.capKey = 'capPartly';
      el.cap.querySelector('span').textContent = t('capPartly');
      el.cap.querySelector('.led').className = 'led warn';
      el.capsLine.textContent = 'WebCodecs · H.264 · 1080p30';
      updateReadout();
    } else {
      state.capKey = 'capReady';
      el.cap.querySelector('span').textContent = t('capReady');
      el.cap.querySelector('.led').className = 'led ok';
      el.capsLine.textContent = 'WebCodecs · H.264 · 4K30';
    }
  }

  /* ── language ───────────────────────────────────────────── */

  function syncLanguage() {
    el.cap.querySelector('span').textContent = t(state.capKey);
    setScreenTag(state.screenState);
    if (state.unpackMeta) fillMeta(state.unpackMeta);
    if (el.verifyMsg.hidden === false && state.lastEncode) {
      if (el.verifyPack.disabled) el.verifyMsg.textContent = t('selfRunning');
    }
    syncReveal();
    updateReadout();
    updateLedger();
    if (!state.busy && el.panelUnpack.hidden === false && !state.unpack) {
      el.screenNote.hidden = true;
    }
  }

  function initLanguage() {
    document.querySelectorAll('[data-lang]').forEach((b) => {
      b.addEventListener('click', () => I18n.set(b.getAttribute('data-lang')));
    });
    document.addEventListener('ytdisk:lang', syncLanguage);
  }

  /* ── boot ───────────────────────────────────────────────── */

  function init() {
    I18n.init();
    initLanguage();
    initTabs();
    initSegs();

    demo.reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (demo.reduce) {
      buildDemo();
      paintPreview(renderer.draw(demo.buf, 0, 16));
      setTc(0);
    } else {
      startDemo();
    }
    setScreenTag('demo');

    wireDrop(el.dropPack, el.filePack, choosePack);
    wireDrop(el.dropUnpack, el.fileUnpack, chooseUnpack);
    el.packClear.addEventListener('click', clearPack);
    el.unpackClear.addEventListener('click', clearUnpack);

    el.pw.addEventListener('input', () => {
      state.password = el.pw.value;
      updateLedger();
    });
    wireReveal(el.pw, el.pwShow);
    wireReveal(el.pw2, el.pwShow2);

    el.goPack.addEventListener('click', runPack);
    el.goUnpack.addEventListener('click', runUnpack);
    el.verifyPack.addEventListener('click', runSelfCheck);

    el.cancelPack.addEventListener('click', () => {
      state.cancel = true;
      el.progSub.textContent = t('errCancelled');
    });
    el.cancelUnpack.addEventListener('click', () => {
      state.cancel = true;
      el.progSub2.textContent = t('errCancelled');
    });

    el.pw2.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !state.busy && state.unpack) runUnpack();
    });

    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => e.preventDefault());

    updateReadout();
    updateLedger();
    syncReveal();
    checkCaps().then(() => {
      syncLanguage();
      updateLedger();
    }).catch(() => {
      state.capKey = 'capMissing';
      syncLanguage();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
