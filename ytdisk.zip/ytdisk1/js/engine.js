/* YTDISK format core: bit packing, frame geometry, header codec.
   Mirrors ytdisk.py section by section so files stay cross-compatible. */
(function (root) {
  'use strict';

  const FMT = {
    GRID_W: 1920,
    GRID_H: 1080,
    FPS: 30,
    BLOCK: 4,
    NSYM: 32,
    RS_N: 255,
    HEADER_BLOCK: 16,
    HEADER_NSYM: 64,
    HEADER_FRAMES: 30,
    MAGIC: 'YTDISK',
    VERSION: 1,
  };

  const H_COLS = Math.floor(FMT.GRID_W / FMT.HEADER_BLOCK);   // 120
  const H_ROWS = Math.floor(FMT.GRID_H / FMT.HEADER_BLOCK);   // 67
  const H_BITS = H_COLS * H_ROWS;                             // 8040
  const H_CAPACITY = Math.floor(H_BITS / 8);                  // 1005
  const H_CODEWORDS = Math.floor(H_CAPACITY / FMT.RS_N);      // 3
  const H_MAX_DATA = H_CODEWORDS * (FMT.RS_N - FMT.HEADER_NSYM); // 573

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  function bytesToBits(bytes) {
    const bits = new Uint8Array(bytes.length * 8);
    for (let i = 0; i < bytes.length; i++) {
      const b = bytes[i];
      const o = i * 8;
      bits[o] = (b >> 7) & 1;
      bits[o + 1] = (b >> 6) & 1;
      bits[o + 2] = (b >> 5) & 1;
      bits[o + 3] = (b >> 4) & 1;
      bits[o + 4] = (b >> 3) & 1;
      bits[o + 5] = (b >> 2) & 1;
      bits[o + 6] = (b >> 1) & 1;
      bits[o + 7] = b & 1;
    }
    return bits;
  }

  function bitsToBytes(bits) {
    const pad = (8 - (bits.length % 8)) % 8;
    const len = (bits.length + pad) / 8;
    const out = new Uint8Array(len);
    for (let i = 0; i < bits.length; i++) {
      if (bits[i]) out[i >> 3] |= 0x80 >> (i & 7);
    }
    return out;
  }

  function grid(block) {
    return [Math.floor(FMT.GRID_W / block), Math.floor(FMT.GRID_H / block)];
  }

  function bitsPerFrame(block) {
    const [c, r] = grid(block);
    return c * r;
  }

  function capacity(block, nsym) {
    const bpf = bitsPerFrame(block);
    const bytesPerFrame = bpf / 8;
    const usefulPerFrame = bytesPerFrame * (FMT.RS_N - nsym) / FMT.RS_N;
    const usefulPerSec = usefulPerFrame * FMT.FPS;
    return {
      cols: grid(block)[0],
      rows: grid(block)[1],
      bitsPerFrame: bpf,
      bytesPerFrame,
      usefulPerFrame,
      usefulPerSec,
      kbPerSec: usefulPerSec / 1024,
      minutesPerGB: 1024 ** 3 / usefulPerSec / 60,
    };
  }

  /** Serialize the 30-frame header payload (765 Reed-Solomon bytes). */
  function buildHeaderBytes(meta) {
    const json = encoder.encode(JSON.stringify(meta));
    if (2 + json.length > H_MAX_DATA) throw new Error('HEADER_TOO_BIG');
    const data = new Uint8Array(H_MAX_DATA);
    data[0] = (json.length >> 8) & 255;
    data[1] = json.length & 255;
    data.set(json, 2);
    return RS.encodeBlock(data, FMT.HEADER_NSYM);   // 765 sequential bytes
  }

  function parseHeaderBytes(bytes) {
    const data = bytes.subarray(0, H_CODEWORDS * FMT.RS_N);
    try {
      const res = RS.decodeBlock(data, FMT.HEADER_NSYM, H_CODEWORDS);
      const msg = res.data;
      const len = (msg[0] << 8) | msg[1];
      if (len <= 0 || 2 + len > msg.length) return null;
      const meta = JSON.parse(decoder.decode(msg.subarray(2, 2 + len)));
      if (!meta || meta.magic !== FMT.MAGIC) return null;
      if (typeof meta.block !== 'number' || typeof meta.frames !== 'number') return null;
      return meta;
    } catch (e) {
      return null;
    }
  }


  /** 4x4 (or block x block) cell grid rendered as black/white pixels. */
  class FrameRenderer {
    constructor() {
      this.cellCanvas = document.createElement('canvas');
      this.cellCtx = this.cellCanvas.getContext('2d', { willReadFrequently: true });
      this.canvas = document.createElement('canvas');
      this.canvas.width = FMT.GRID_W;
      this.canvas.height = FMT.GRID_H;
      this.ctx = this.canvas.getContext('2d');
      this.ctx.imageSmoothingEnabled = false;
      this.block = 0;
      this.cols = 0;
      this.rows = 0;
    }

    setBlock(block) {
      if (this.block === block) return;
      const [cols, rows] = grid(block);
      this.block = block;
      this.cols = cols;
      this.rows = rows;
      this.cellCanvas.width = cols;
      this.cellCanvas.height = rows;
      this.image = this.cellCtx.createImageData(cols, rows);
      const px = this.image.data;
      for (let i = 3; i < px.length; i += 4) px[i] = 255;
    }

    /** Draw packed bytes, starting at bit `bitOffset`, onto the 1920x1080 canvas. */
    draw(bytes, bitOffset, block) {
      this.setBlock(block);
      const px = this.image.data;
      const n = this.cols * this.rows;
      const totalBits = bytes.length * 8;
      for (let i = 0; i < n; i++) {
        const bi = bitOffset + i;
        let on = 0;
        if (bi < totalBits) on = (bytes[bi >> 3] >> (7 - (bi & 7))) & 1 ? 255 : 0;
        const p = i * 4;
        px[p] = on; px[p + 1] = on; px[p + 2] = on;
      }
      this.cellCtx.putImageData(this.image, 0, 0);
      const ctx = this.ctx;
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, FMT.GRID_W, FMT.GRID_H);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.cellCanvas, 0, 0, this.cols * block, this.rows * block);
      return this.canvas;
    }
  }

  class FrameReader {
    constructor() {
      this.canvas = document.createElement('canvas');
      this.canvas.width = FMT.GRID_W;
      this.canvas.height = FMT.GRID_H;
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
      this.image = null;
    }

    /** Draw a decoded VideoFrame at 1920x1080 and return its pixels. */
    grab(frame) {
      const ctx = this.ctx;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(frame, 0, 0, FMT.GRID_W, FMT.GRID_H);
      return ctx.getImageData(0, 0, FMT.GRID_W, FMT.GRID_H).data;
    }

    /** Sample one cell grid out of pixels returned by grab(). */
    bitsFrom(img, block, outBytes) {
      const cols = Math.floor(FMT.GRID_W / block);
      const rows = Math.floor(FMT.GRID_H / block);
      const nBits = cols * rows;
      const nBytes = Math.ceil(nBits / 8);
      const out = outBytes || new Uint8Array(nBytes);
      out.fill(0);
      const half = block >> 1;
      const sx = half - 1;
      const sy = half - 1;
      let bi = 0;
      for (let cy = 0; cy < rows; cy++) {
        const y0 = cy * block + sy;
        for (let cx = 0; cx < cols; cx++) {
          const x0 = cx * block + sx;
          let sum = 0;
          for (let dy = 0; dy < 2; dy++) {
            const row = (y0 + dy) * FMT.GRID_W;
            for (let dx = 0; dx < 2; dx++) {
              const p = (row + x0 + dx) * 4;
              sum += img[p] * 0.299 + img[p + 1] * 0.587 + img[p + 2] * 0.114;
            }
          }
          if (sum > 4 * 127) out[bi >> 3] |= 0x80 >> (bi & 7);
          bi++;
        }
      }
      return out;
    }

    /** Draw a decoded VideoFrame and return packed bytes for one frame. */
    read(frame, block, outBytes) {
      return this.bitsFrom(this.grab(frame), block, outBytes);
    }
  }

  async function sha256Hex(bytes) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  root.Engine = {
    FMT, H_BITS, H_MAX_DATA, H_CAPACITY,
    bytesToBits, bitsToBytes, grid, bitsPerFrame, capacity,
    buildHeaderBytes, parseHeaderBytes, FrameRenderer, FrameReader, sha256Hex,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.Engine;
})(typeof globalThis !== 'undefined' ? globalThis : this);
