/* Reed-Solomon over GF(256), compatible with the Python `reedsolo` defaults:
   primitive poly 0x11d, generator 2, first consecutive root fcr = 0.
   Codeword layout: k message bytes followed by `nsym` parity bytes. */
(function (root) {
  'use strict';

  const PRIM = 0x11d;
  const N = 255;
  const EXP = new Uint8Array(512);
  const LOG = new Uint8Array(256);

  (function init() {
    let x = 1;
    for (let i = 0; i < N; i++) {
      EXP[i] = x;
      LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= PRIM;
    }
    for (let i = N; i < 512; i++) EXP[i] = EXP[i - N];
  })();

  const mul = (a, b) => (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]];
  const div = (a, b) => (a === 0) ? 0 : EXP[(LOG[a] + N - LOG[b]) % N];
  const pow = (a, n) => {
    if (n === 0) return 1;
    if (a === 0) return 0;
    return EXP[((LOG[a] * n) % N + N) % N];
  };

  const genCache = new Map();
  function generator(nsym) {
    let g = genCache.get(nsym);
    if (g) return g;
    g = new Uint8Array(nsym + 1);
    g[0] = 1;
    let deg = 0;
    for (let i = 0; i < nsym; i++) {
      const root = EXP[i];               // (x - a^i) == (x + a^i) in GF(2^m)
      g[deg + 1] = mul(g[deg], root);
      for (let j = deg; j >= 1; j--) g[j] ^= mul(g[j - 1], root);
      deg++;
    }
    genCache.set(nsym, g);
    return g;
  }

  /** One codeword: msg (length <= 255-nsym) -> msg || parity */
  function encodeChunk(msg, nsym) {
    const k = N - nsym;
    if (msg.length > k) throw new Error('rs: message longer than ' + k);
    const gen = generator(nsym);
    const out = new Uint8Array(k + nsym);
    out.set(msg, 0);
    for (let i = 0; i < k; i++) {
      const coef = out[i];
      if (coef !== 0) {
        const lc = LOG[coef];
        for (let j = 1; j <= nsym; j++) {
          const gc = gen[j];
          if (gc !== 0) out[i + j] ^= EXP[LOG[gc] + lc];
        }
      }
    }
    out.set(msg, 0);                       // synthetic division dirtied the message bytes
    return out;
  }

  /** Sequential blocks (no interleaving) — used by the header. */
  function encodeBlock(data, nsym) {
    const k = N - nsym;
    const nBlocks = Math.ceil(data.length / k) || 1;
    const padded = new Uint8Array(nBlocks * k);
    padded.set(data);
    const out = new Uint8Array(nBlocks * N);
    for (let b = 0; b < nBlocks; b++) {
      out.set(encodeChunk(padded.subarray(b * k, (b + 1) * k), nsym), b * N);
    }
    return out;
  }

  /** Matches ytdisk.ecc_encode: pad, encode, then transpose (interleave). */
  function encodeInterleaved(data, nsym) {
    if (nsym === 0) return data.slice();
    const k = N - nsym;
    const nBlocks = Math.ceil(data.length / k) || 1;
    const padded = new Uint8Array(nBlocks * k);
    padded.set(data);
    const out = new Uint8Array(nBlocks * N);
    for (let b = 0; b < nBlocks; b++) {
      const cw = encodeChunk(padded.subarray(b * k, (b + 1) * k), nsym);
      for (let j = 0; j < N; j++) out[j * nBlocks + b] = cw[j];
    }
    return out;
  }

  function syndromes(msg, nsym) {
    const s = new Uint8Array(nsym);
    for (let j = 0; j < nsym; j++) {
      let v = 0;
      const root = EXP[j];
      for (let i = 0; i < msg.length; i++) v = mul(v, root) ^ msg[i];
      s[j] = v;
    }
    return s;
  }

  function berlekampMassey(synd, nsym) {
    let C = [1];
    let B = [1];
    let L = 0;
    let m = 1;
    let b = 1;
    for (let n = 0; n < nsym; n++) {
      let d = synd[n];
      for (let i = 1; i <= L; i++) d ^= mul(C[i] || 0, synd[n - i]);
      if (d === 0) {
        m++;
        continue;
      }
      const coef = div(d, b);
      const T = C.slice();
      const next = C.slice();
      while (next.length < B.length + m) next.push(0);
      for (let i = 0; i < B.length; i++) next[i + m] ^= mul(coef, B[i]);
      C = next;
      if (2 * L <= n) {
        L = n + 1 - L;
        B = T;
        b = d;
        m = 1;
      } else {
        m++;
      }
    }
    return C.slice(0, L + 1);
  }

  /** Solve V * e = s over GF(256) for a small Vandermonde system. */
  function solveVandermonde(X, s) {
    const t = X.length;
    const A = [];
    for (let r = 0; r < t; r++) {
      const row = new Uint8Array(t + 1);
      for (let c = 0; c < t; c++) row[c] = pow(X[c], r);
      row[t] = s[r];
      A.push(row);
    }
    for (let col = 0; col < t; col++) {
      let piv = -1;
      for (let r = col; r < t; r++) if (A[r][col] !== 0) { piv = r; break; }
      if (piv < 0) throw new Error('rs: singular system');
      [A[col], A[piv]] = [A[piv], A[col]];
      const inv = div(1, A[col][col]);
      for (let c = col; c <= t; c++) A[col][c] = mul(A[col][c], inv);
      for (let r = 0; r < t; r++) {
        if (r === col || A[r][col] === 0) continue;
        const f = A[r][col];
        for (let c = col; c <= t; c++) A[r][c] ^= mul(f, A[col][c]);
      }
    }
    const out = new Uint8Array(t);
    for (let i = 0; i < t; i++) out[i] = A[i][t];
    return out;
  }

  /** Correct one codeword in place. Returns number of corrected symbols. */
  function decodeChunk(cw, nsym) {
    if (nsym === 0) return 0;
    const synd = syndromes(cw, nsym);
    let clean = true;
    for (let i = 0; i < nsym; i++) if (synd[i] !== 0) { clean = false; break; }
    if (clean) return 0;

    const loc = berlekampMassey(synd, nsym);
    const deg = loc.length - 1;
    if (deg === 0 || deg * 2 > nsym) throw new Error('rs: too many errors');

    // Chien search: find X with Lambda(1/X) = 0, X = a^(n-1-pos)
    const positions = [];
    const Xs = [];
    for (let p = 0; p < cw.length; p++) {
      const e = (255 - 1 - p) % 255;          // exponent of X = a^e
      // evaluate Lambda(X^-1) = sum_i loc[i] * a^(-e*i)
      let v = 0;
      for (let i = 0; i < loc.length; i++) {
        if (loc[i] === 0) continue;
        const ex = (((-e * i) % 255) + 255) % 255;
        v ^= mul(loc[i], EXP[ex]);
      }
      if (v === 0) { positions.push(p); Xs.push(EXP[(e + 255) % 255]); }
    }
    if (positions.length !== deg) throw new Error('rs: locator roots not found');

    const mags = solveVandermonde(Xs, synd);
    for (let i = 0; i < positions.length; i++) cw[positions[i]] ^= mags[i];

    const after = syndromes(cw, nsym);
    for (let i = 0; i < nsym; i++) if (after[i] !== 0) throw new Error('rs: uncorrectable');
    return positions.length;
  }

  function decodeBlock(data, nsym, nBlocks) {
    const total = (nBlocks || Math.floor(data.length / N)) * N;
    const out = new Uint8Array(total - (nBlocks || Math.floor(data.length / N)) * nsym);
    let fixed = 0;
    const blocks = nBlocks || Math.floor(data.length / N);
    for (let b = 0; b < blocks; b++) {
      const cw = data.slice(b * N, (b + 1) * N);
      fixed += decodeChunk(cw, nsym);
      out.set(cw.subarray(0, N - nsym), b * (N - nsym));
    }
    return { data: out, fixed };
  }

  /** Matches ytdisk.ecc_decode. Throws when a codeword cannot be recovered. */
  function decodeInterleaved(data, nCodewords, nsym) {
    if (nsym === 0) return { data: data.slice(), fixed: 0 };
    const total = nCodewords * N;
    if (data.length < total) throw new Error('rs: not enough data');
    const k = N - nsym;
    const out = new Uint8Array(nCodewords * k);
    let fixed = 0;
    const cw = new Uint8Array(N);
    for (let b = 0; b < nCodewords; b++) {
      for (let j = 0; j < N; j++) cw[j] = data[j * nCodewords + b];
      fixed += decodeChunk(cw, nsym);
      out.set(cw.subarray(0, k), b * k);
    }
    return { data: out, fixed };
  }

  root.RS = { encodeChunk, encodeBlock, encodeInterleaved, decodeBlock, decodeInterleaved, decodeChunk, mul, div, pow, EXP, LOG };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.RS;
})(typeof globalThis !== 'undefined' ? globalThis : this);
