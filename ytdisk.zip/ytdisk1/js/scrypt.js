/* scrypt (RFC 7914) with N = 2^15, r = 8, p = 1 — the exact KDF ytdisk uses,
   plus AES-256-GCM via WebCrypto in the same salt|nonce|ciphertext layout. */
(function (root) {
  'use strict';

  function rotl(x, n) { return (x << n) | (x >>> (32 - n)); }

  function salsa208(B, x, out) {
    for (let i = 0; i < 16; i++) x[i] = B[i];
    for (let i = 0; i < 8; i += 2) {
      x[4] ^= rotl(x[0] + x[12], 7);  x[8] ^= rotl(x[4] + x[0], 9);
      x[12] ^= rotl(x[8] + x[4], 13); x[0] ^= rotl(x[12] + x[8], 18);
      x[9] ^= rotl(x[5] + x[1], 7);   x[13] ^= rotl(x[9] + x[5], 9);
      x[1] ^= rotl(x[13] + x[9], 13); x[5] ^= rotl(x[1] + x[13], 18);
      x[14] ^= rotl(x[10] + x[6], 7); x[2] ^= rotl(x[14] + x[10], 9);
      x[6] ^= rotl(x[2] + x[14], 13); x[10] ^= rotl(x[6] + x[2], 18);
      x[3] ^= rotl(x[15] + x[11], 7); x[7] ^= rotl(x[3] + x[15], 9);
      x[11] ^= rotl(x[7] + x[3], 13); x[15] ^= rotl(x[11] + x[7], 18);
      x[1] ^= rotl(x[0] + x[3], 7);   x[2] ^= rotl(x[1] + x[0], 9);
      x[3] ^= rotl(x[2] + x[1], 13);  x[0] ^= rotl(x[3] + x[2], 18);
      x[6] ^= rotl(x[5] + x[4], 7);   x[7] ^= rotl(x[6] + x[5], 9);
      x[4] ^= rotl(x[7] + x[6], 13);  x[5] ^= rotl(x[4] + x[7], 18);
      x[11] ^= rotl(x[10] + x[9], 7); x[8] ^= rotl(x[11] + x[10], 9);
      x[9] ^= rotl(x[8] + x[11], 13); x[10] ^= rotl(x[9] + x[8], 18);
      x[12] ^= rotl(x[15] + x[14], 7); x[13] ^= rotl(x[12] + x[15], 9);
      x[14] ^= rotl(x[13] + x[12], 13); x[15] ^= rotl(x[14] + x[13], 18);
    }
    for (let i = 0; i < 16; i++) out[i] = (B[i] + x[i]) | 0;
  }

  function blockMix(B, r, X, Y, tmp) {
    const bw = 16, R = 2 * r;
    for (let k = 0; k < bw; k++) X[k] = B[(R - 1) * bw + k];
    for (let i = 0; i < R; i++) {
      for (let k = 0; k < bw; k++) X[k] ^= B[i * bw + k];
      salsa208(X, tmp, Y.subarray(i * bw, (i + 1) * bw));
      for (let k = 0; k < bw; k++) X[k] = Y[i * bw + k];
    }
    // B' = (Y0, Y2, ... , Y(2r-2), Y1, Y3, ... , Y(2r-1))
    for (let i = 0; i < r; i++) {
      B.set(Y.subarray(2 * i * bw, (2 * i + 1) * bw), i * bw);
      B.set(Y.subarray((2 * i + 1) * bw, (2 * i + 2) * bw), (r + i) * bw);
    }
  }

  function romix(B, N, r) {
    const blockWords = 32 * r;
    const X = new Int32Array(blockWords);
    const Y = new Int32Array(blockWords);
    const Bx = new Int32Array(blockWords);
    const tmp = new Int32Array(16);
    for (let i = 0; i < blockWords; i++) X[i] = B[i];
    const V = new Int32Array(N * blockWords);
    for (let i = 0; i < N; i++) {
      V.set(X, i * blockWords);
      blockMix(X, r, Bx, Y, tmp);
    }
    for (let i = 0; i < N; i++) {
      const j = (X[blockWords - 16] & (N - 1));
      const off = j * blockWords;
      for (let k = 0; k < blockWords; k++) X[k] ^= V[off + k];
      blockMix(X, r, Bx, Y, tmp);
    }
    for (let i = 0; i < blockWords; i++) B[i] = X[i];
  }

  function bytesToWordsLE(bytes) {
    const words = new Int32Array(bytes.length / 4);
    for (let i = 0; i < words.length; i++) {
      const o = i * 4;
      words[i] = bytes[o] | (bytes[o + 1] << 8) | (bytes[o + 2] << 16) | (bytes[o + 3] << 24);
    }
    return words;
  }

  function wordsToBytesLE(words) {
    const bytes = new Uint8Array(words.length * 4);
    for (let i = 0; i < words.length; i++) {
      const w = words[i];
      bytes[i * 4] = w & 255;
      bytes[i * 4 + 1] = (w >>> 8) & 255;
      bytes[i * 4 + 2] = (w >>> 16) & 255;
      bytes[i * 4 + 3] = (w >>> 24) & 255;
    }
    return bytes;
  }

  const enc = new TextEncoder();

  async function pbkdf2(password, salt, bytes) {
    const key = await crypto.subtle.importKey('raw', password, 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 1 }, key, bytes * 8);
    return new Uint8Array(bits);
  }

  async function scrypt(password, salt, opts) {
    const N = (opts && opts.N) || 32768;
    const r = (opts && opts.r) || 8;
    const p = (opts && opts.p) || 1;
    const dkLen = (opts && opts.dkLen) || 32;
    const pw = typeof password === 'string' ? enc.encode(password) : password;
    const blockBytes = 128 * r;
    const B = await pbkdf2(pw, salt, p * blockBytes);
    for (let i = 0; i < p; i++) {
      const words = bytesToWordsLE(B.subarray(i * blockBytes, (i + 1) * blockBytes));
      romix(words, N, r);
      B.set(wordsToBytesLE(words), i * blockBytes);
    }
    return pbkdf2(pw, B, dkLen);
  }

  const SALT_LEN = 16, NONCE_LEN = 12;

  async function encrypt(data, password) {
    const salt = crypto.getRandomValues(new Uint8Array(SALT_LEN));
    const nonce = crypto.getRandomValues(new Uint8Array(NONCE_LEN));
    const keyBytes = await scrypt(password, salt);
    const key = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['encrypt']);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, key, data);
    const out = new Uint8Array(SALT_LEN + NONCE_LEN + ct.byteLength);
    out.set(salt, 0);
    out.set(nonce, SALT_LEN);
    out.set(new Uint8Array(ct), SALT_LEN + NONCE_LEN);
    return out;
  }

  async function decrypt(blob, password) {
    if (blob.length <= SALT_LEN + NONCE_LEN) throw new Error('ciphertext too short');
    const salt = blob.subarray(0, SALT_LEN);
    const nonce = blob.subarray(SALT_LEN, SALT_LEN + NONCE_LEN);
    const ct = blob.subarray(SALT_LEN + NONCE_LEN);
    const keyBytes = await scrypt(password, salt);
    const key = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
    try {
      const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: nonce }, key, ct);
      return new Uint8Array(pt);
    } catch (e) {
      throw new Error('WRONG_PASSWORD');
    }
  }

  root.Scrypt = { scrypt, encrypt, decrypt };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.Scrypt;
})(typeof globalThis !== 'undefined' ? globalThis : this);
